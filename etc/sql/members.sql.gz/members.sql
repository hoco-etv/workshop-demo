-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 06, 2017 at 12:16 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `members`
--
CREATE DATABASE IF NOT EXISTS `members` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `members`;

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `registration` date DEFAULT NULL,
  `deregistration` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `associate_members`
--

CREATE TABLE `associate_members` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `registration` date NOT NULL,
  `deregistration` date DEFAULT NULL,
  `expiration` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `associations`
--

CREATE TABLE `associations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `study` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_postal_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_town` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_internal` tinyint(1) NOT NULL DEFAULT '0',
  `visit_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_postal_code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_town` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visit_country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number1` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number2` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_of_address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `salutation` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `magazine` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `associations`
--

INSERT INTO `associations` (`id`, `name`, `type`, `study`, `mail_address`, `mail_postal_code`, `mail_town`, `mail_country`, `mail_internal`, `visit_address`, `visit_postal_code`, `visit_town`, `visit_country`, `phone_number1`, `phone_number2`, `fax`, `email`, `form_of_address`, `salutation`, `website`, `magazine`, `comments`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Electrotechnische Vereeniging', 'Studievereniging', 'Electrical Engineering', 'Mekelweg 4', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786189', '015-2781399', '015-2781002', 'bestuur@etv.tudelft.nl', 'Geacht Bestuur', 'Aan het Bestuur van de', 'www.etv.tudelft.nl', '', '144.2 -- 142.3\n144.2 -- 140.5 (who''s next, Bart?)\nETV b''vo b''vo', NULL, '2016-11-28 16:21:14', '2017-01-30 16:47:26'),
(2, 'U.F.S.W. Alcmaeon', 'Faculteitsvereniging', 'Sociale Wetenschappen', 'Heidelberglaan 1', '3584 CS', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2533200', '030-2534898', '', 'info@alcmaeon.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.alcmaeon.nl', '', '139.1 -- 21.5\n142.2 -- 21.5\n142.2.-- 24.7\n142.5 -- 24.7\n141.5 -- 24.7\n145.5 -- 27.2\n\nSletjes!', NULL, '2016-11-28 16:21:14', '2017-01-26 10:46:44'),
(3, 'Studievereniging Emile', 'Studievereniging', 'Pedagogische Wetenschappen', 'Wassenaarseweg 52, kamer SB05', '2333 AK', 'Leiden', 'Nederland', 0, '', '', '', '', '071-5273685', '', '', 'emile@fsw.leidenuniv.nl', 'Geacht Bestuur', 'Aan het bestuur van', 'studievereniging-emile.nl', '', '139.5 -- 21.4 (ex)\n142.2 -- 23.2\n142.2 -- 24.5 (ex)\n142.5 -- 25.3\n\nSletjes, snappen niet veel. Maar wel leuk clubje. Leuke feestjes met elektro! ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(4, 'W.I.S.V. Christiaan Huygens', 'Studievereniging', 'Technische Wiskunde & Technische Informatica', 'Mekelweg 4', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '015-2782532', '015-2787208', '', 'bestuur@ch.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'ch.tudelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(5, 'Studievereniging LIFE', 'Studievereniging', 'Life Science & Technology', 'Van der Maasweg 9 kamer C.0.090', '2629 HZ', 'Delft', 'Nederland', 1, 'Einsteinweg 55, Kamer 008B', '2333 CC', 'Leiden', 'Nederland', '015-2782155', '071-5274334', '015-2782355', 'bestuur@svlife.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.svlife.nl', '', '142.4 -- 17.2\n145.2 -- 20.1\n145.2 -- 20.3\n\nTwee adressen... Fax 2: 071-5274537 \nLeuk clubje. Bestuur 2013 is super chill. Ook leuk om mee te eten. Feestje met elektro is zeker een optie', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(6, 'Vereniging voor Technische Physica', 'Studievereniging', 'Technische Natuurkunde', 'Lorentzweg 1, kamer A109', '2628 CJ', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786122', '', '', 'vvtp@vvtp.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.vvtp.tudelft.nl', '', 'Dochtertje', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(7, 'Gezelschap Leeghwater', 'Studievereniging', 'Werktuigbouwkunde', 'Mekelweg 2', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786501', '', '015-2781443', 'info@leeghwater.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.leeghwater.nl', '', 'Altyd lastig', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(8, 'S.V.T.B. Curius', 'Studievereniging', 'Technische Bestuurskunde', 'Jaffalaan 5', '2628 BX', 'Delft', 'Nederland', 1, '', '', '', '', '015-2783406', '', '015-2784811', 'info@curius.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.curius.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(9, 'Mijnbouwkundige Vereeniging', 'Studievereniging', 'Technische Aardwetenschappen', 'Stevinweg 1, kamer 01.120', '2628 CN', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786039', '', '', 'mv@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.mv.tudelft.nl', '', 'MV Gluck auf', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(10, 'Gezelschap Practische Studie', 'Studievereniging', 'Civiele Techniek', 'Stevinweg 1, kamer 1.65', '2628 CN', 'Delft', 'Nederland', 1, '', '', '', '', '015-2785465', '', '015-2781104', 'info-PS@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.ps.tudelft.nl', '', 'Leuk tijdens het grondboren', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(11, 'D.B.S.G. Stylos', 'Studievereniging', 'Bouwkunde', 'Julianalaan 132-134, BG. midden 110', '2628 BL', 'Delft', 'Nederland', 1, '', '', '', '', '015-2783697', '', '', 'info@stylos.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.stylos.nl', '', 'Leuke mensen. Hebben weinig geld en niet zo''n goede band met de faculteit. Zijn door brand veel verloren. Wel erg leuk', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(12, 'Technologisch Gezelschap', 'Studievereniging', 'Molecular Science & Technology', 'Julianalaan 136, kamer 024', '2628 BL', 'Delft', 'Nederland', 1, '', '', '', '', '015-2784315', '', '', 'tg@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'tg.tudelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(13, 'Studievereniging i.d', 'Studievereniging', 'Industrieel Ontwerpen', 'Landbergstraat 15', '2628 CE', 'Delft', 'Nederland', 1, '', '', '', '', '015-2783012', '015-2783237', '', 'svid@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.id.tudelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(14, 'S.G. William Froude', 'Studievereniging', 'Maritieme Techniek', 'Mekelweg 2', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786562', '', '', 'info@froude.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.froude.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(15, 'VSV ''Leonardo da Vinci''', 'Studievereniging', 'Lucht- en Ruimtevaarttechniek', 'Kluyverweg 1', '2629 HS', 'Delft', 'Nederland', 1, '', '', '', '', '015-2785366', '', '015-2781243', 'vsv@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.vsv.tudelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(16, 'ECU''92', 'Studievereniging', 'Economie', 'Postbus 80125', '3508 TC', 'Utrecht', 'Nederland', 0, 'Kriekenpitplein 18 - 19', '3584 EC ', 'Utrecht', 'Nederland', '030-2539680', '', '030-2536392', 'bestuur@ecu92.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.ecu92.nl', '', 'Leuk clubje. Ga zeker naar de diesreceptie en zuip jezelf naar huis. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(17, 'AEGEE Delft', 'Studentenvereniging', '', 'Leeghwaterstraat 42', '2628 CA', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786933', '', '', 'board@aegee-delft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.aegee-delft.nl', '', 'Oud: AEGEE-DelftrnLeeghwaterstraat 42rn2628 CA rnDelft rn', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(18, 'A-Eskwadraat', 'Studievereniging', 'Wiskunde, Informatica en Natuurkunde', 'Princetonplein 5, kamer 269', '3584 CC', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2534499', '', '', 'bestuur@A-Eskwadraat.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.a-eskwadraat.nl', '', 'Leuke mensen. \nFeestjes van A-eskwadraat zijn bèta. Wel leuk. \n\nCobo had grolsch beugels en is erg gezellig.\nIn 2014 was het in de oude catacombe zonder beugels en erg suf, tot de ETV langs kwam en het stuk maakte: aanrader\n \nDe diesreceptie is ook erg leuk.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(19, 'Amsterdams Chemisch Dispuut', 'Studievereniging', 'Scheikunde', 'Science Park 904, kamer A0.09', '1098 XH', 'Amsterdam', 'Nederland', 0, '', '', '', '', '020-5257861', '', '', 'acd@science.uva.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.science.uva.nl/student/acd/acd2', '', 'Hebben een lelijk blaadje waar wel een leuke puzzel in staat. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(20, 'B.I.L.', 'Studievereniging', 'Bestuurskunde', 'Wassenaarseweg 52', '2333 AK', 'Leiden', 'Nederland', 0, '', '', '', '', '071-5273696', '', '071-5273979', 'info@bilboard.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.bilboard.nl', '', 'Langharige tuig uit het jaar van 142 stinkt en zit bij minerva. Ze voelen zich geweldig. \n\nZusje Loopik doet er Bestuur in het jaar van 143', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(21, 'C.S.R. Delft', 'Studentenvereniging', '', 'Oude Delft 9', '2611 BA', 'Delft', 'Nederland', 0, '', '', '', '', '015-2135681', '', '', 'bestuur@csrdelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'csrdelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(22, 'D.S.K.', 'Studievereniging', 'Diergeneeskunde', 'Yalelaan 1', '3584 CL', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2534678', '', '', 'dsk.bestuur@uu.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.dskonline.nl', '', 'Peerdepieten, altyd zoo geweescht over de baan in je bak. Een Baron is veel gaver. Leuk om te bellen.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(23, 'D.S.R. Proteus-Eretes', 'Studentenvereniging', '', 'Rotterdamseweg 362A', '2628 AT ', 'Delft', 'Nederland', 0, '', '', '', '', '015-2623720', '015-2622772', '', 'info@proteus-eretes.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.proteus-eretes.nl/', '', 'dsr. slaven', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(24, 'De Leidsche Flesch', 'Studievereniging', 'Natuurkunde, Sterrenkunde, Wiskunde en Informatica', 'Niels Bohrweg 1, kamer 301', '2333 CA', 'Leiden', 'Nederland', 0, '', '', '', '', '071-5277070', '', '071-5277101', 'bestuur@deleidscheflesch.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.deleidscheflesch.nl', '', 'Leuke mensen. Feestjes zijn bèta. Facfeest is opzich wel grappig en bètagala is bètafala. Desalnietemin wel heengaan', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(25, 'Delftsch Studenten Corps', 'Studentenvereniging', '', 'Phoenixstraat 30', '2611 AL', 'Delft', 'Nederland', 0, '', '', '', '', '015-2150030', '', '', 'senaat@delft.corps.nl', 'Geacht senaat', 'Aan de senaat van', 'delft.corps.nl', '', 'dsc, ''vo', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(26, 'Delftsche Studenten Bond', 'Studentenvereniging', '', 'Oude Delft 123', '2611 BE', 'Delft', 'Nederland', 0, '', '', '', '', '015-2122123', '015-2134960', '', 'nfo@delftschestudentenbond.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.delftschestudentenbond.nl', '', 'dsb, kroeg', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(27, 'D.S.J.V. Groover', 'Studenten Jazz Vereniging', '', 'Mekelweg 10', '2628 CD', 'Delft', 'Nederland', 0, '', '', '', '', '06-13893175', '', '', 'bestuur@grooverjazz.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.grooverjazz.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(28, 'Micro-Electronic Systems and Technology Association', 'Studievereniging', 'Microelectronics & Computer Engineering ', 'Mekelweg 4', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '', '', '', 'mest@et.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.mest-delft.nl/', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(29, 'E.T.S.V. Scintilla', 'Studievereniging', 'Electrical Engineering', 'Postbus 217', '7500 AE', 'Enschede', 'Nederland', 0, 'Zilverling E-204 (gebouw 11)', '', 'Enschede', 'Nederland', '053-4892810', '', '053-4891068', 'bestuur@scintilla.utwente.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.scintilla.utwente.nl/', '', '142: Bestuur bestaat maar uit twee mensen dit jaar. Probeer ze een beetje te helpen. Is wel een dochterje.\n\n143.2: Bestuur bestaat uit 6 man waarvan 5 fulltime. Gaat wel redelijk. Neem nare dingen mee naar de CoBo.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(30, 'e.t.s.v. Thor', 'Studievereniging', 'Electrical Engineering', 'Postbus 513', '5600 MB', 'Eindhoven', 'Nederland', 0, 'Potentiaal 2.24', '', '', '', '040-2473223', '', '040-2448375', 'bestuur@thor.edu', 'Geacht bestuur', 'Aan het bestuur van', 'www.thor.edu', '', 'Ja, dit is echt met kleine letters. Ze zijn beetje knorrig en boersch, maar leuke borrellocatie. Ze vinden het ook heel leuk als jabo een boekje komt brengen. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(31, 'Faculteitsvereniging Aureus', 'Faculteitsvereniging', 'Economie en Bedrijfseconomie, Bedrijfskunde en International Business Administration', 'De Boelelaan 1105, kamer 2A-11', '1081 HV', 'Amsterdam', 'Nederland', 0, 'De Boelelaan 1105, kamer 6A-03', '1081 HV', 'Amsterdam', 'Nederland', '020-5986135', '020-5986154', '', 'info@aureus-vu.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.aureus-vu.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(32, 'FMF', 'Studievereniging', '(Technische) Wiskunde, (Technische) Natuurkunde, Informatica en Sterrenkunde', 'Nijenborgh 4', '9747 AG', 'Groningen', 'Nederland', 0, '', '', '', '', '050-3634948', '050-3634155', '', 'bestuur@fmf.nl', 'Geacht bestuur', 'Aan het bestuur van', 'fmf.nl', '', 'Wiskunde uit Groningen. Probeer langs te gaan als je zin hebt. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(33, 'NWSV Helix', 'Studievereniging', 'Natuurwetenschap & Innovatiemanagement en Science & Innovationmanagement', 'Heidelberglaan 2', '3584 CS', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2538345', '', '', 'helix@geo.uu.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.nwsvhelix.nl', '', 'Incapabel maar kan gezellig zijn. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(34, 'IEEE Student Branch Delft', 'Studievereniging', 'Electrical Engineering', 'Mekelweg 4, LB 01.330', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '', '', '', 'sb.delft@ieee.org', 'Geacht bestuur', 'Aan het bestuur van de', '', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(35, 'Io Vivat Nostrorum Sanitas', 'Studentenvereniging', 'Hogere Hotelschool', 'Postbus 2577', '8901 AB', 'Leeuwarden', 'Nederland', 0, 'Herenwaltje 5', '8911 HN', 'Leeuwarden', 'Nederland', '058-2159239', '', '', 'info@iovivat.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.iovivat.nl', '', 'Clubje van hoger hotelschool moeilijk ver weg. Hebben altijd een gala. Leuk om heen te gaan.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(36, 'JSVU', 'Studievereniging', 'Rechtsgeleerdheid', 'Jansveld 44', '3512 BH', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2400811', '030-2367475', '', 'bestuur@jsvu.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.jsvu.nl', '', 'Leuk clubje uit Utrecht. Geven erg goede feestjes. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(37, 'K.S.V. Sanctus Virgilius', 'Studentenvereniging', '', 'Oude Delft 57', '2611 BC', 'Delft', 'Nederland', 0, '', '', '', '', '015-2151617', '', '015-2124157', 'info@virgiel.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.virgiel.nl/', '', 'virgiel, toko', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(38, 'L.M.D. Forestus', 'Dispuut', '', 'Postbus 9600', '2300 RC', 'Leiden', 'Nederland', 0, 'Albinusdreef 2, K1-71', '2333 ZA', 'Leiden', 'Nederland', '071-5264527', '', '', 'bestuur@forestus.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.forestus.nl', '', '142.2 -- 33.3\nDispuut van MFLS. Erg leuk. Ga ook zeker naar een party.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(39, 'L.P.S.V. Aesculapius', 'Studievereniging', 'Bio-Farmaceutische Wetenschappen', 'Postbus 9502 ', '2300 RA', 'Leiden', 'Nederland', 0, '', '', '', '', '071-5274601', '', '', 'bestuur@aesculapius.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.aesculapius.nl', '', 'Biologie Aapjes, ook wel aescalatius genoemd. Aescaleren echter nooit. Voelen zich heel wat. Beetje Leeghwater van Leiden. 142 klinkt echter moeilijk prominent waardoor ze zich jong voelen. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(40, 'Leidse Biologen Club', 'Studievereniging', 'Biologie', 'Sylviusweg 72', '2333 BE', 'Leiden', 'Nederland', 0, '', '', '', '', '071-5274977', '', '', 'bestuur@leidsebiologenclub.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.leidsebiologenclub.nl', '', 'lbc, leidsche borrel club!', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(41, 'M.B.V. Mebiose', 'Studievereniging', 'Biomedische Wetenschappen', 'Hamburgerstraat 27', '3512 NP', 'Utrecht', 'Nederland', 0, 'Universiteitsweg 100, Stratenum, kamer 0.314c', '3584 CG', 'Utrecht', 'Nederland', '030-2382931', '088-7568953', '', 'mebiose@umcutrecht.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.mebiose.nl', '', 'Erg gezellige vereniging. Hebben ook de Utrechtse Besturenborrel. 140 en 142 waren erbij', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(42, 'M.F.L.S.', 'Studievereniging', 'Biomedische Wetenschappen en Geneeskunde', 'Postbus 9600', '2300 RC', 'Leiden', 'Nederland', 0, 'Albinusdreef 2, LUMC K1-69', '2333 ZA', 'Leiden', 'Nederland', '071-5264484', '', '', 'info@mfls.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'mfls.nl', '', '144.5 -- 103.2\nProbeer het contact te herstellen. \nniet hopen', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(43, 'M.F.V.U.', 'Studievereniging', 'Geneeskunde', 'Van der Boechorstraat 7, kamer D-014', '1081 BT', 'Amsterdam', 'Nederland', 0, '', '', '', '', '020-4448353', '', '020-4448398', 'info@mfvu.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'http://www.mfvu.nl/', '', 'Leuk doch incapabel. Diesreceptie is leuk. Cobo iets minder. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(44, 'M.S.F.U. Sams', 'Studievereniging', 'Geneeskunde', 'Hamburgerstraat 27', '3512 NP', 'Utrecht', 'Nederland', 0, 'Universiteitsweg 100, Stratenum', '3584 CG', 'Utrecht', 'Nederland', '030-2328298', '088-7568990', '', 'bestuur@msfusams.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.msfusams.nl', '', '141.5 -- 31.5\n\n2011-2012: Geile chickies 13/14 Leuk clubje ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(45, 'O.J.V. De Koornbeurs', 'Studentenvereniging', '', 'Voldersgracht 1', '2611 ET', 'Delft', 'Nederland', 0, '', '', '', '', '015-2124742', '', '', 'bestuur@koornbeurs.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.koornbeurs.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(46, 'ORAS-fractie', 'Studentenraad TU Delft', '', 'Mekelweg 4, HB 20.110', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '015-2783349', '015-2781768', '', 'info@oras.nl', 'Geachte fractie', 'Aan de', 'www.oras.nl', '', 'Als Oras komt eten, is het bier op. Je drinkt dus alleen maar vlek. Tip1, eet Chinees. Dat brokt lekker. Tip2, laat Oras toezeggingen doen tijdens dit diner. Dat is handig als je bijvoorbeeld een intens gave groene bank of groene vissen wil. Let wel op dat je geen ontbijtje bestelt. Als je Oras belt, begin je altijd met Halloras.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(47, 'S.V.R.', 'Studievereniging', '', 'Leeghwaterstraat 42', '2628 CA', 'Delft', 'Nederland', 1, '', '', '', '', '015-2786348', '', '', 'bestuur@svr.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.svr.tudelft.nl/', '', 'Ga lekker met ze zuipen', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(48, 'Sterkstroomdispuut', 'Dispuut', 'Electrical Power Engineering', 'Mekelweg 4', '2628 CD', 'Delft', 'Nederland', 1, 'Mekelweg 4 - LB 03.910', '2628 CD', 'Delft', '', '015-2783784', '', '015-2781182', 'bestuur@sterkstroomdispuut.nl', 'Geacht bestuur', 'Aan het bestuur van het', 'www.sterkstroomdispuut.nl', '', 'SSD', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(49, 'StuD', 'Studentenuitzendbureau', '', 'Mekelweg 3', '2628 CC', 'Delft', 'Nederland', 1, '', '', '', '', '015-2788786', '', '015-2788696', 'info@stud.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.stud.nl', '', 'Ook leuk', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(50, 'D.S.V. ', 'Studentenvereniging', '', 'Buitenwatersloot 1-3', '2613 TA', 'Delft', 'Nederland', 0, '', '', '', '', '015-2126012', '', '', 'info@nieuwedelft.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.debolk.nl', '', 'Bolk', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(51, 'D.S.V. Sint Jansbrug', 'Studentenvereniging', '', 'Oude Delft 50-52', '2611 CD', 'Delft', 'Nederland', 0, '', '', '', '', '015-2120619', '', '', 'bestuur@jansbrug.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.sintjansbrug.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(52, 'Mensenvereniging Wolbodo', 'Studentenvereniging', '', 'Verwersdijk 102', '2611 NK', 'Delft', 'Nederland', 0, '', '', '', '', '015-2121516', '', '', 'bestuur@wolbodo.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.wolbodo.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(53, 'Biologenvereniging Congo', 'Studievereniging', 'Biologie', 'Postbus 94214', '1090 GE', 'Amsterdam', 'Nederland', 0, 'Science Park 904, Kamer B0.172', '1098 XH', 'Amsterdam', 'Nederland', '020-5257853', '020-5257863', '', 'info@congo.eu', 'Geacht bestuur', 'Aan het bestuur van', 'www.congo.eu', '', '140.1 -- 93.4\n\nKunnen erg weinig, maar zijn wel erg gezellig. Ga langs!', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(54, 'Dispuut Johannes Calvijn', 'Dispuut studentenvereniging', '', 'Postbus 288', '2600 AG', 'Delft', 'Nederland', 0, '', '', '', '', '', '', '', 'bestuur.jc@csfr.nl', 'Geacht bestuur', 'Aan het bestuur van', 'csfr-delft.nl', '', 'dispuut der C.S.F.R.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(55, 'D.S.R.V. Laga', 'Studenten Roeivereniging', '', 'Nieuwelaan 53', '2611 RR', 'Delft', 'Nederland', 0, '', '', '', '', '015-2125266', '', '', 'laga@laga.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.laga.nl', '', 'slaven', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(56, 'NSR', 'Studentenvereniging', '', 'Eendrachtsplein 10', '3012 LA', 'Rotterdam', 'Nederland', 0, '', '', '', '', '010-4045322', '', '', 'info@nsr.nu', 'Geacht bestuur', 'Aan het bestuur van', 'www.nsr.nu', '', 'Navigators Studentenvereniging Rotterdam', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(57, 'VGSD', 'Studentenvereniging', '', 'Postbus 1080', '2600 BB', 'Delft', 'Nederland', 0, 'Kromstraat 14', '2611 ER', 'Delft', '', '06-48921122', '', '', 'abactis@vgsd.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.vgsd.nl', '', 'V.G.S.D.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(58, 'Studentenstam de Delftsche Zwervers', 'Studentenvereniging', '', 'Schiekade 3', '2627 BL', 'Delft', 'Nederland', 0, '', '', '', '', '', '', '', 'voorzitter@delftschezwervers.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.delftschezwervers.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(59, 'D.S.W.Z. Broach', 'Studenten Wedstrijdzeilvereniging', '', 'Mekelweg 8', '2628 CD', 'Delft', 'Nederland', 0, '', '', '', '', '', '', '', 'bestuur@wedstrijdzeilen.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.broach.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(60, 'DSMG Krashna Musika', 'Studenten Muziek Gezelschap', '', 'Postbus 554', '2600 AN', 'Delft', 'Nederland', 0, 'Mekelweg 10', '2628 CD', 'Delft', 'Nederland', '06-43253221', '', '', 'krashna@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'krashna.nl/', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(61, 'D.S.V.V. "Punch"', 'Studenten Volleybal Vereniging', '', 'Brabantse Turfmarkt 9', '2611 CK', 'Delft', 'Nederland', 0, 'Brabantse Turfmarkt 9', '2611 CK', 'Delft', 'Nederland', '015-2123412', '06-24467580', '', 'bestuur@punch.tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.punch.tudelft.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(62, 'D.S.T.V. Obvius', 'Studenten Tennis Vereniging', '', 'Mekelweg 8', '2628 CD', 'Delft', 'Nederland', 0, '', '', '', '', '', '', '', 'bestuur@dstvobvius.nl', 'Geacht bestuur', 'Aan het bestuur van', 'dstvobvius.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(63, 'Lijst βèta', 'Studentenraad TU Delft', '', 'Mekelweg 4, HB 20.150', '2628 CD', 'Delft', '', 1, '', '', '', '', '015-2787289', '', '', 'info@lijstbeta.nl', 'Geachte fractie', 'Aan de fractie van', 'www.lijstbeta.nl', '', '143: dit jaar heet Sjoerd Chris, en hij heeft de schijtlijst gewonnen.\n\n142: Sjoerd komt gratisch koffie claimen. Dat komt omdat hij met twee vrouwen op de kamer zit en hij zo nu en dan behoefte heeft aan mannelijkheid', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(64, 'Utrechtse Aardwetenschappen Vereniging', 'Studievereniging', 'Aardwetenschappen', 'Princetonplein 5, kamer 277', '3584 CC', 'Utrecht', '', 0, 'Princetonplein 5, kamer 277', '3584 CC', 'Utrecht', '', '030-2532019', '', '', 'uav@uu.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'http://www.uavonline.nl', '', 'uav\n\nJan is verliefd op de preases van 71', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(65, 'V.U.G.S.', 'Studievereniging', 'Geografie', 'Leuvenlaan 19', '3584 CE', 'Utrecht', '', 0, '', '', '', '', '030-2532789', '', '030-2540604', 'vugs@geo.uu.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.vugs.nl', '', 'Vereniging van Utrechtse Geografie Studentenrn 140 heeft dit contact opgezet na een constitutieborrel bij A-eskwadraat, erg gezellig! Zijn inderdaad best gezellig', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(66, 'STIP', 'Studentenfractie', '', 'Markt 87', '2611 GS', 'Delft', '', 0, '', '', '', '', '015-2602820', '', '015-2197184', 'stip@delft.nl', 'Geachte fractie', 'Aan de fractie van', 'stipdelft.nl/', '', 'Leuke mensen. Als je met ze gaat eten, eet bij hun. Gave locatie', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(67, 'K.N.P.S.V.', 'Studievereniging', 'Pharmacie', 'Antonius Deusinglaan 1', '9713 AV', 'Groningen', '', 0, '', '', '', '', '050-3638605', '', '', 'secretaris@knpsv.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'http://www.knpsv.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(68, 'T.M.F.V. Archigenes', 'Studievereniging', 'Tandheelkunde Mondhygiëne', 'Antonius Deusinglaan 1', '9713 AV', 'Groningen', '', 0, '', '', '', '', '050-3638745', '', '', 'bestuur@archigenes.nl', 'Geacht bestuur', 'Aan het bestuur der', 'http://www.archigenes.nl/', '', 'Wie de fuck zijn dit? Kennen we van grondboren', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(69, 'Economische Faculteitsvereniging Rotterdam', 'Faculteitsvereniging', 'Economie', 'Burgemeester Oudelaan 50', '3062 PA', 'Rotterdam', '', 0, '', '', '', '', '0104081146', '', '0104082892', 'info@efr.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.efr.nl', '', 'Nieuw contact sinds 2011/2012. Geen contact in 13/14.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(70, 'Di-et-Tri', 'Studievereniging', 'Voeding & Gezondheid', 'Droevendaalsesteeg 2, kamer 118', '6708 PB', 'Wageningen', '', 0, '', '', '', '', '0317-484270', '', '', 'diettri@wur.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.diettri.nl', '', '142.2 -- (2014-2015).4\n\nKroegentocht in 2014 was een success, raadpleeg de fotoschijf voor meer gelach\n\nZe hebben bussen met vrouwen. Bel ze hiervoor!\n\n', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(71, 'USCKI Incognito', 'Studievereniging', 'Cognitieve Kunstmatige Intelligentie', 'Janskerkhof 13a, k. 1.06', '3512 BL', 'Utrecht', '', 0, 'Drift 21, k. 206', '3512 BR', 'Utrecht', '', '030-2538127', '', '', 'incognito@uscki.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.uscki.nl', '', 'Op de CoBo was het bier snel op', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(72, 'U.S.S. Proton', 'Studievereniging', 'Scheikunde', 'Princetonplein 5', '3584 CC', 'Utrecht', '', 0, '', '', '', '', '030-2531631', '', '', 'bestuur@ussproton.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.ussproton.nl', '', 'Feestjes zijn erg bèta', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(73, 'Tandheelkundige FaculteitsVereniging Nijmegen', 'Studievereniging', 'Tandheelkunde', 'Philips van Leydenlaan 25', '6525 EX', 'Nijmegen', '', 0, '', '', '', '', '024-3614047', '', '', 'tfv@dent.umcn.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.tfvn.nl', '', 'tfvn', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(74, 'Studievereniging Sticky', 'Studievereniging', 'Informatica en Informatiekunde', 'Princetonplein 5', '3584 CC', 'Utrecht', '', 0, '', '', '', '', '06-38514324', '', '', 'info@stickyutrecht.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.stickyutrecht.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(75, 'MSV Santé', 'Studievereniging', 'Gezondheidswetenschappen', 'Postbus 616', '6200 MD', 'Maastricht', '', 0, 'Universiteitssingel 40', '6229 ER', 'Maastricht', '', '043-3881695', '', '', 'msvsante@maastrichtuniversity.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.msvsante.nl', '', 'Gezellig', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(76, 'T.S.V. ''Jan Pieter Minckelers''', 'Studievereniging', 'Scheikundige Technologie', 'Postbus 513', '5600 MB', 'Eindhoven', '', 0, 'Helix, STW 0.25', '5600 MB', 'Eindhoven', '', '040-2473756', '', '040-2442576', 'japie@tue.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.tsvjapie.nl', '', 'Stuurt altijd kaartjes. Schijnen niets te kunnen. Feestjes zijn best ok', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(77, 'Labyrint', 'Studievereniging', 'Psychologie', 'Wassenaarseweg 52, k. SA55', '2333 AK', 'Leiden', '', 0, '', '', '', '', '071-5273618', '', '', 'bestuur@labyrintleiden.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.labyrintleiden.nl', '', 'Leuke feestjes', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(78, 'VSSD', 'Vakbond', '', 'Leeghwaterstraat 42', '2628 CA', 'Delft', '', 1, '', '', '', '', '015-2782050', '', '', 'balie@vssd.nl', 'Geacht bestuur', 'Aan het bestuur van de', 'www.vssd.nl', '', 'Kunnen niet heel veel. Ga keihard Vlek met ze zuipen.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(79, 'Vlaamse Technische Kring', 'Faculteitskring', 'Burgerlijk Ingenieur', 'Studentenwijk arenberg 6, bus 0', '3001', 'Heverlee', 'België', 0, '', '', '', '', '+3216-200097', '', '+3216-206529', 'vtk@vtk.be', 'Geacht bestuur', 'Aan het bestuur van de', 'www.vtk.be', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(80, 'Studievereniging Pyrus', 'Studievereniging', 'Bodem, Water, Atmosfeer', 'Droevendaalsesteeg 2', '6708 PB', 'Wageningen', '', 0, 'Forum, kamer 116', '6708 PB', 'Wageningen', '', '0317-485034', '', '', 'pyrus.bwa@wur.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.pyrusbwa.nl', '', 'Bereikbaar op werkdagen tussen 12.15 en 13.15. Ga erheen voor gronboren en ontken dat er een edelmangrondboor in het bezit van de ETV is', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(81, 'W.S.G. Isaac Newton', 'Studievereniging', 'Werktuigbouwkunde', 'Postbus 217', '7500 AE', 'Enschede', '', 0, '', '', '', '', '053-4892531', '', '053-4894005', 'bestuur@isaacnewton.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.isaacnewton.nl', '', 'Kapot maken indien mogelijk. Altijd leuk', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(82, 'Corpus Delicti (CoDe)', 'Studievereniging', 'Criminologie ', 'Steenschuur 25, kamer C1.02', '2311 ES ', 'Leiden', 'Nederland', 0, 'Steenschuur 25, Kamer A0.37', '2311 ES', 'Leiden', 'Nederland', '071-5277158', '', '', 'corpusdelicti@law.leidenuniv.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.codeleiden.nl/index.php', '', '142.1 -- 11.6\n142.5 -- 12.6\n143.1 -- 12.1\n143.2 -- 13.4\n144.3 -- 13.2\n145.3 -- 13.2\n\nLeuk voor feestjes met emile. Verder ook erg gezellig. \n\nDaniel en Erné zijn lid van code', NULL, '2016-11-28 16:21:14', '2017-01-26 10:45:54'),
(83, 'Pallas Athene C.S.H.H.', 'Studentenvereniging', '', 'Postbus 851', '2501 CW ', '''s-Gravenhage', 'Nederland', 0, 'Bierkade 13', '', '''s-Gravenhage', '', '0703603142', '', '', 'bestuur@pallas-athene.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.pallas-athene.nl/', '', 'Zus van 1401 deed er ooit Bestuur', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(84, 'W.S.V. Simon Stevin', 'Studievereniging', 'Werktuigbouwkunde', 'Postbus 513', '5600 MB', 'Eindhoven', '', 0, 'Gemini-Noord 1.61', '5600 MB', 'Eindhoven', '', '040-2473313', '', '040-2434970', 'secretaris@simonstevin.tue.nl', 'Geacht Bestuur', 'Aan het Bestuur van', 'www.simonstevin.tue.nl', '', 'Eerste contact 13-8-2012. Zijn kapot gemaakt bij knor', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(85, 'Medische Faculteit der Amsterdamsche Studenten', 'Studievereniging', 'Geneeskunde', 'Meibergdreef 15, kamer J0-110', '1105 AZ', 'Amsterdam', '', 0, 'Meibergdreef 15, kamer J0-110', '1105 AZ', 'Amsterdam', '', '020-5664674', '', '', 'mfas@mfas.net', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.mfas.net', '', 'Opzich wel gezellig. Kunnen meer dan MFVU', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(86, 'Studievereniging Complex', 'Studievereniging', 'Psychologie', 'Postbus 90153', '5000 LE', 'Tilburg', '', 0, 'Kamer P3.224', '5000 LE', 'Tilburg', '', '013-4662758', '', '', 'secretariscomplex@gmail.com', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.complextilburg.nl', '', 'Met dank aan Fieback', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(87, 'Angstrom', 'Studievereniging', 'Technische Natuurkunde', 'Rotterdamseweg 137', '2628 AL ', 'Delft', '', 0, 'Rotterdamseweg 137', '2628 AL ', 'Delft', '', '015-2606326', '', '', 'bestuur@angstrom.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.angstrom.nl/', '', 'HHS vereniging van TN. Kunnen voor HHs begrippen veel. Voor TU begrippen intens weinig. Echt heel weinig', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(88, 'Studievereniging PAP', 'Studievereniging', 'Pedagogische Wetenschappen', 'Heidelberglaan 1', '3584 CS', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2534885', '', '', 'info@svpap.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.svpap.nl', '', 'SLETJES', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(89, 'Aureus', 'Studievereniging', 'Economics and Business Administration', 'De Boelelaan 1105, room 2A-11 ', '1081 HV', 'Amsterdam', 'Nederland', 0, 'De Boelelaan 1105, room 6A-03 ', '1081 HV ', 'Amsterdam', 'Nederland', '020-5986135', '020-5986154', '', 'info@aureus-vu.nl', 'Geacht Bestuur', 'Faculty Association Aureus', 'http://www.aureus-vu.nl/', '', 'Stuurt altijd uitnodigingen. Misschien wel leuk', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(90, 'EGEA', 'Studievereniging', 'Reisgenootschap Geografische Studies', 'P.O.Box 80.115', '3508 TC ', 'Utrecht', 'Nederland', 0, 'Leuvenlaan 21', '3584 CE', 'Utrecht', 'Nederland', '030-2539708', '', '030-2540604', 'egea@egea.eu', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.egea.eu/', '', '142.2 -- 26.1\nEx van Fieback doet er Bestuur. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(91, 'NOVA', 'Scholierenvereniging', '', 'Rotterdamseweg 137', '2628 AL', 'Delft', 'Nederland', 0, '', '', '', '', '015-2606227', '', '', 'info@sv-nova.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.sv-nova.nl/', '', 'Scholierenclubje van de Haagse Hogeschool. Kunnen bijzonder weinig, maar dat spreekt redelijk voor zich met HBO''ers. De website staat bovendien vol met spelfouten.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(92, 'V.S.V. Sypke Wynia', 'Studievereniging', 'Luchtvaartechnologie', 'Postbus 3190 t.a.v. Sipke Wynia', '2601 DD', 'Delft', '', 0, 'Rotterdamseweg 141', '2628 AL', 'Delft', '', '015-2519238', '', '', 'ejw@sipkewynia.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.sipkewynia.nl/', '', 'Hogeschool Inholland Delft', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(93, 'Itiwana', 'Studievereniging', 'Culturele Antropologie en Ontwikkelingssociologie', 'Wassenaarseweg 52  (Kamer SB-07)', '2333 AK', 'Leiden', '', 0, 'Wassenaarseweg 52  (Kamer SB-07)', '2333 AK', 'Leiden', '', '071-5274025', '', '', 'info@itiwana.org', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.itiwana.org', '', 'Stelletje HA\n\nhebben een leuk gala voor 15 euro', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(94, 'GSV Excalibur', 'Studievereniging', 'Geschiedenis', 'Erasmusplein 1', '6525 HT', 'Nijmegen', '', 0, 'Erasmusplein 1 (Kamer 1.60a/9.14)', '6525 HT', 'Nijmegen', '', '024-3612294', '', '', 'excalibur@let.ru.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://gsvexcalibur.nl/', '', 'Excaliboor! We kennen ze eigenlijk niet, maar de naam deed 142 denken aan het NSK grondboren.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(95, 'Juridische Faculteitsvereniging Grotius', 'Studievereniging', 'Rechten', 'Steenschuur 25 ', '2311 ES', 'Leiden', '', 0, 'Steenschuur 25  A0.43 ', '2311 ES', 'Leiden', '', '071-5277546', '', '', 'bestuur@jfvgrotius.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.jfvgrotius.nl', '', '142 probeert hier contact mee te zoeken\n\n145 is het gelukt.', NULL, '2016-11-28 16:21:14', '2016-11-30 15:28:36'),
(96, 'Studievereniging De Veetelers', 'Studievereniging', 'Dierwetenschappen', 'De Elst 1', '6708 WD', 'Wageningen', '', 0, '', '', '', '', '0317-483984', '0317-483962', '', '', 'Geacht bestuur', 'Aan het bestuur van', 'http://beta.veetelers.nl/', '', 'Stelletje boeren maar schijnen wel gezellig te zijn', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(97, 'Studievereniging Animo', 'Studievereniging', 'Algemene Cultuurwetenschappen', 'Postbus 90153 (Dante-gebouw 1e verdieping)', '5000 LE', 'Tilburg', '', 0, 'Postbus 90153 Kantoor: D114', '5000 LE', 'Tilburg', '', '', '', '', 'info@animotilburg.nl ', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.animotilburg.nl/', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(98, 's.v.i.d. Lucid', 'Studievereniging', 'Industrieel Ontwerpen', 'Den Dolech 2 ', '5612 AZ', 'Eindhoven', '', 0, 'Den Dolech 2 ', '5612 AZ', 'Eindhoven', '', '040-2474181', '', '', 'lucid@tue.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://lucid.cc/', '', 'Apaten die over de bar klimmen bij de cobo van i.d, hardhandig de tent uit gewerkt', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(99, 'HSVL', 'Studievereniging', 'Geschiedenis', 'Doelensteeg 16', '2311 VL', ' Leiden', '', 0, '', '', '', '', '071-5272352', '', '', 'info@dehsvl.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://dehsvl.nl', '', 'Historische Studievereniging Leiden. Waren niet actief in 13/14\n\n144 heeft er toevallig gereceptieerd, zijn erg gezellige mensen ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(100, 'SIB-Leiden', 'Studentenvereniging', '', 'Kaiserstraat 25', '2311 GN', 'Leiden', 'Nederland', 0, 'Kaiserstraat 25', '2311 GN', 'Leiden', 'Nederland', '0-715277559', '', '', 'bestuur@sibleiden.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.sibleiden.nl', '', 'Studentenvereniging voor internationale betrekkingen. Waren op cobo 142', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(101, 'Utrechtse Biologen Vereniging', 'Studievereniging', 'Biologie', 'Princetonplein 5', '3584 CC', 'Utrecht', 'Nederland', 0, '', '', '', '', '030-2536741', '', '', 'Bestuur@UBV.info', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.projects.science.uu.nl/ubv/', '', 'Utrechtse Borrel Vereniging. Feestjes zijn bèta', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(102, 'FSET', 'Fachschaft', 'Electrical Engineering', 'Kármánstraße 9', '52062', 'Aachen', 'Deutschland', 0, '', '', '', '', '0241-8097574', '', '', 'fset@rwth-aachen.de', 'Dear Board', 'To the Board of', 'https://www.fset.rwth-aachen.de/', '', 'Elektro in Aken. Onderdeel van IDEA league. Hebben best een leuke bestuurskamer. Contact opgezet door 142. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(103, 'Econometrisch Dispuut', 'Studievereniging', 'Econometrie', 'PO BOX 1738', '3000 DR', 'Rotterdam', '', 0, 'Burgemeester Oudlaan 50, Room H10-05', '3062 PA', 'Rotterdam', '', '010-4081439', '', '', 'ed@ectrie.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://www.ectrie.nl/', '', 'Hebben een blaadje voor scholieren wat wellicht interessant kan zijn.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(104, 'AMIV', 'Studievereniging', 'Electrical Engineering', 'Universitätsstrasse 6', 'CH-8092', 'Zürich', 'Switzerland', 0, 'Sonneggstrasse 3', '8052', 'Zürich', 'Switzerland', '', '', '', 'https://www.amiv.ethz.ch/', 'Dear Board', 'To the Board of', 'kontakt@amiv.ethz.ch', '', 'Leuke gasten. Ga er zeker langs als je in de buurt bent. De kelk uit 57 komt van hen, in 75 zijn we langsgekomen en in andere jaren nog veel meer. Iedereen lijkt dat echter te vergeten. ', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(105, 'Studiestichting Alias', 'Studievereniging', 'Taal- en Cultuurstudies', 'Trans 10', '3512 JK', 'Utrecht', 'Nederland', 0, 'Drift 21, kamer 1.03', '3512 BR', 'Utrecht', 'Nederland', '0302536225', '', '', 'info[at]aliasweb.nl', 'Geacht bestuur', 'Aan het bestuur van', 'aliasweb.nl', '', 'Chicks! 27ste Bestuur heeft een hele leuke onderwijs. Ander functies ook wel ok, alleen Extern is gruwelijk.', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(106, 'S.V.N.B. Hooke', 'Studievereniging', 'Nanobiologie', 'Van der Maasweg 9 D0.120', '2629 HZ', 'Delft', '', 1, 'Van der Maasweg 9 D0.120', '2629 HZ', 'Delft', '', '015-2781639', '', '', 'bestuur-hooke@tudelft.nl', 'Geacht bestuur', 'Aan het bestuur van', '', '', 'Kleindochtertje van ons, dochter van VvTP. Bestuur is in 2014 bezig met als voorzitter Captain Hooke', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(107, 'Variscopic', 'Studievereniging', 'Klinische Technologie', 'Mekelweg 2', '2628 CD', 'Delft', '', 1, 'afdeling E2', '', '', '', '0152785947', '', '', 'secretaris@variscopic.nl', 'Geacht bestuur', 'Aan het bestuur van', 'http://variscopic.nl/', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(108, 'YES!Delft Students', '', '', 'Molengraaffsingel 12', '2629 JD', 'Delft', '', 0, 'Molengraaffsingel 12', '2629 JD', 'Delft', '', '0152782936', '', '', 'info@yesdelftstudents.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.yesdelftstudents.nl', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(109, 'GLV Idun', 'studievereniging', 'LST/Biologie', 'Nijenborgh 7 Gebouw 5173, Kamer 0171 ', '9747 AG', 'Groningen', 'Nederland', 0, '', '', '', '', '+31503632074', '', '', 'bestuur@idun.nl', 'Geacht bestuur', 'Aan het bestuur van', 'https://www.idun.nl/', '', '144 was toevallig bij eindfeest door de koop van hun bak', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(110, 'nieuwe vereniging', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(111, 'Nieuwe vereniging', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '2016-12-21 14:09:09', '2016-12-21 14:09:09'),
(112, 'Students4Sustainability', 'Studentenorganisatie', '', 'Mekelweg 8', '2628 CD', 'Delft', 'Nederland', 1, '', '', '', '', '', '', '', 'info@students4sustainability.nl', 'Geacht bestuur', 'Aan het bestuur van', 'www.students4sustainability.nl', '', 'Philip oud-secretaris', NULL, '2016-12-21 14:09:34', '2017-01-20 13:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `boards`
--

CREATE TABLE `boards` (
  `id` int(11) NOT NULL,
  `number` smallint(3) DEFAULT NULL,
  `adjective` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `motto` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` char(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '000000',
  `lustrum` tinyint(1) NOT NULL DEFAULT '0',
  `installation` date DEFAULT NULL,
  `installation_precision` enum('day','month','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `discharge` date DEFAULT NULL,
  `discharge_precision` enum('day','month','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `boards`
--

INSERT INTO `boards` (`id`, `number`, `adjective`, `motto`, `color`, `lustrum`, `installation`, `installation_precision`, `discharge`, `discharge_precision`, `description`, `created_at`, `updated_at`) VALUES
(1, NULL, '', '', '000000', 0, '1906-03-01', 'month', '1907-01-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2, NULL, '', '', '000000', 0, '1907-01-01', 'month', '1907-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(3, NULL, '', '', '000000', 0, '1907-05-01', 'month', '1908-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4, NULL, '', '', '000000', 0, '1908-05-01', 'month', '1909-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(5, NULL, '', '', '000000', 0, '1909-02-01', 'month', '1909-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(6, NULL, '', '', '000000', 0, '1909-03-01', 'month', '1910-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(7, NULL, '', '', '000000', 0, '1910-04-01', 'month', '1911-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(8, NULL, '', '', '000000', 1, '1911-02-01', 'month', '1911-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(9, NULL, '', '', '000000', 0, '1911-05-01', 'month', '1911-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(10, NULL, '', '', '000000', 0, '1911-11-01', 'month', '1912-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(11, NULL, '', '', '000000', 0, '1912-02-01', 'month', '1912-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(12, NULL, '', '', '000000', 0, '1912-05-01', 'month', '1913-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(13, NULL, '', '', '000000', 0, '1913-10-01', 'month', '1914-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(14, NULL, '', '', '000000', 0, '1914-10-01', 'month', '1915-01-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(15, NULL, '', '', '000000', 0, '1915-01-01', 'month', '1915-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(16, NULL, '', '', '000000', 0, '1915-11-01', 'month', '1916-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(17, NULL, '', '', '000000', 1, '1916-02-01', 'month', '1916-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(18, NULL, '', '', '000000', 0, '1916-10-01', 'month', '1917-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(19, NULL, '', '', '000000', 0, '1917-09-01', 'month', '1918-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(20, NULL, '', '', '000000', 0, '1918-09-01', 'month', '1919-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(21, NULL, '', '', '000000', 0, '1919-12-01', 'month', '1920-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(22, NULL, '', '', '000000', 0, '1920-02-01', 'month', '1920-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(23, NULL, '', '', '000000', 1, '1920-12-01', 'month', '1921-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(24, NULL, '', '', '000000', 0, '1921-03-01', 'month', '1921-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(25, NULL, '', '', '000000', 0, '1921-12-01', 'month', '1922-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(26, NULL, '', '', '000000', 0, '1922-04-01', 'month', '1922-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(27, NULL, '', '', '000000', 0, '1922-12-01', 'month', '1923-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(28, NULL, '', '', '000000', 0, '1923-09-01', 'month', '1923-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(29, NULL, '', '', '000000', 0, '1923-11-01', 'month', '1924-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(30, NULL, '', '', '000000', 0, '1924-02-01', 'month', '1924-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(31, NULL, '', '', '000000', 0, '1924-10-01', 'month', '1925-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(32, NULL, '', '', '000000', 0, '1925-03-01', 'month', '1925-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(33, NULL, '', '', '000000', 1, '1925-10-01', 'month', '1926-08-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(34, NULL, '', '', '000000', 0, '1926-08-01', 'month', '1927-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(35, NULL, '', '', '000000', 0, '1927-10-01', 'month', '1928-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(36, NULL, '', '', '000000', 0, '1928-10-01', 'month', '1929-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(37, NULL, '', '', '000000', 0, '1929-11-01', 'month', '1930-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(38, NULL, '', '', '000000', 1, '1930-10-01', 'month', '1931-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(39, NULL, '', '', '000000', 0, '1931-10-01', 'month', '1932-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(40, NULL, '', '', '000000', 0, '1931-10-01', 'month', '1932-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(41, NULL, '', '', '000000', 0, '1932-10-01', 'month', '1932-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(42, NULL, '', '', '000000', 0, '1932-12-01', 'month', '1933-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(43, NULL, '', '', '000000', 0, '1933-11-01', 'month', '1934-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(44, NULL, '', '', '000000', 0, '1934-10-01', 'month', '1935-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(45, NULL, '', '', '000000', 0, '1935-03-01', 'month', '1935-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(46, NULL, '', '', '000000', 0, '1935-10-01', 'month', '1936-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(47, NULL, '', '', '000000', 1, '1936-02-01', 'month', '1936-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(48, NULL, '', '', '000000', 0, '1936-09-01', 'month', '1936-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(49, NULL, '', '', '000000', 0, '1936-12-01', 'month', '1937-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(50, NULL, '', '', '000000', 0, '1937-05-01', 'month', '1937-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(51, NULL, '', '', '000000', 0, '1937-11-01', 'month', '1938-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(52, NULL, '', '', '000000', 0, '1938-02-01', 'month', '1938-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(53, NULL, '', '', '000000', 0, '1938-11-01', 'month', '1939-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(54, NULL, '', '', '000000', 0, '1939-11-01', 'month', '1940-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(55, NULL, '', '', '000000', 1, '1940-10-01', 'month', '1941-07-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(56, NULL, '', '', '000000', 0, '1941-07-01', 'month', '1945-08-31', 'month', 'Dit bestuur heeft tijdens een deel van de Tweede Wereldoorlog de Electrotechnische Vereeniging geleid. Het is onbekend wanneer zij gedechargeerd zijn.', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(57, NULL, '', '', '000000', 1, '1945-10-01', 'month', '1946-04-01', 'month', 'Na de bevrijding is er een voorlopig bestuur geformeerd, die de taken tijdelijk heeft waargenomen. In de vergadering van 24 Oktober 1945 werd zij geïnstalleerd:\r\n\r\nR.F. Storm - [b]President[/b]\r\nW. van Luttervelt - [b]Secretaris[/b]\r\nW.H.L. van Helsdingen - [b]Thesaurier[/b]\r\nJ.N. van Hall - [b]Vice-President[/b]\r\nL. van Honert - [b]Commissaris[/b]\r\n\r\nIn dezelfde vergadering werd zij gechargeerd en werd het bovengenoemde bestuur geïnstalleerd.', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(58, NULL, '', '', '000000', 0, '1946-04-01', 'month', '1946-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(59, NULL, '', '', '000000', 0, '1946-10-01', 'month', '1947-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(60, NULL, '', '', '000000', 0, '1947-05-01', 'month', '1947-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(61, NULL, '', '', '000000', 0, '1947-10-01', 'month', '1948-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(62, NULL, '', '', '000000', 0, '1948-05-01', 'month', '1948-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(63, NULL, '', '', '000000', 0, '1948-11-01', 'month', '1949-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(64, NULL, '', '', '000000', 0, '1949-02-01', 'month', '1949-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(65, NULL, '', '', '000000', 0, '1949-10-01', 'month', '1950-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(66, NULL, '', '', '000000', 0, '1950-02-01', 'month', '1950-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(67, NULL, '', '', '000000', 1, '1950-11-01', 'month', '1951-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(68, NULL, '', '', '000000', 0, '1951-04-01', 'month', '1951-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(69, NULL, '', '', '000000', 0, '1951-11-01', 'month', '1952-01-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(70, NULL, '', '', '000000', 0, '1952-01-01', 'month', '1952-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(71, NULL, '', '', '000000', 0, '1952-04-01', 'month', '1952-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(72, NULL, '', '', '000000', 0, '1952-10-01', 'month', '1953-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(73, NULL, '', '', '000000', 0, '1953-05-01', 'month', '1953-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(74, NULL, '', '', '000000', 0, '1953-10-01', 'month', '1954-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(75, NULL, '', '', '000000', 0, '1954-04-01', 'month', '1954-11-04', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(76, NULL, '', '', '000000', 0, '1954-11-04', 'month', '1955-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(77, NULL, '', '', '000000', 0, '1955-05-01', 'month', '1955-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(78, NULL, '', '', '000000', 1, '1955-11-01', 'month', '1956-07-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(79, NULL, '', '', '000000', 0, '1956-07-01', 'month', '1956-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(80, NULL, '', '', '000000', 0, '1956-09-01', 'month', '1957-01-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(81, NULL, '', '', '000000', 0, '1957-01-01', 'month', '1957-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(82, NULL, '', '', '000000', 0, '1957-05-01', 'month', '1957-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(83, NULL, '', '', '000000', 0, '1957-12-01', 'month', '1958-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(84, NULL, '', '', '000000', 0, '1958-04-01', 'month', '1958-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(85, NULL, '', '', '000000', 0, '1958-10-01', 'month', '1959-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(86, NULL, '', '', '000000', 0, '1959-05-01', 'month', '1959-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(87, NULL, '', '', '000000', 0, '1959-11-01', 'month', '1960-06-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(88, NULL, '', '', '000000', 0, '1960-06-01', 'month', '1960-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(89, NULL, '', '', '000000', 1, '1960-11-01', 'month', '1961-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(90, NULL, '', '', '000000', 0, '1961-05-01', 'month', '1961-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(91, NULL, '', '', '000000', 0, '1961-10-01', 'month', '1962-06-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(92, NULL, '', '', '000000', 0, '1962-06-01', 'month', '1962-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(93, NULL, '', '', '000000', 0, '1962-11-01', 'month', '1963-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(94, NULL, '', '', '000000', 0, '1963-03-01', 'month', '1963-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(95, NULL, '', '', '000000', 0, '1963-05-01', 'month', '1963-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(96, NULL, '', '', '000000', 0, '1963-11-01', 'month', '1964-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(97, NULL, '', '', '000000', 0, '1964-05-01', 'month', '1965-01-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(98, NULL, '', '', '000000', 1, '1965-01-01', 'month', '1965-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(99, NULL, '', '', '000000', 0, '1965-05-01', 'month', '1965-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(100, NULL, '', '', '000000', 0, '1965-10-01', 'month', '1966-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(101, NULL, '', '', '000000', 0, '1966-04-01', 'month', '1966-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(102, NULL, '', '', '000000', 0, '1966-11-01', 'month', '1967-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(103, NULL, '', '', '000000', 0, '1967-11-01', 'month', '1968-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(104, NULL, '', '', '000000', 0, '1968-11-01', 'month', '1969-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(105, NULL, '', '', '000000', 0, '1969-11-01', 'month', '1970-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(106, NULL, '', '', '000000', 1, '1970-11-01', 'month', '1971-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(107, NULL, '', '', '000000', 0, '1971-12-01', 'month', '1972-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(108, NULL, '', '', '000000', 0, '1972-11-01', 'month', '1973-11-01', 'month', 'Het bestuur 1972-1973 laat zich het best kenschetsen door de uitspraken opgenomen in het ETV Jaarboek 1973:<br />\r\n<br />\r\n- Op President: Zeeziekte? Nee, lachkramp!<br />\r\n- Op Vice-President: Ik zeg maar zo, ik zeg maar niets en dan heb ik alteveel gezegd.<br />\r\n- Op onze buschauffeur naar Duitsland: Net niet raak is ook mis.<br />\r\n- Secretaresse over bestuurslid: Ik heb wel andere methoden om aan een aanzoek te komen.<br />\r\n- Verzoek binnen gekomen bij onze thesaurier: Ik kan het bedrag niet inenen betalen. Mag ik het in drie keer betalen?<br />\r\n- Citaat uit verslag Afdelings Raad Elektrotechniek: Opening ...... - De Kroes deelt namens Boerema en Lemstra mede, dat de excursie van de ETV naar Zweden uitstekend verloopt...<br />\r\n<br />\r\nAls U de afdruk van de uitnodiging voor de reunie van de Zweden Excursie, gemaakt door Ir. Maarten van der Werf wilt zien, moet U hier klikken. De UNK-stichting.', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(109, NULL, '', '', '000000', 0, '1973-11-01', 'month', '1974-04-01', 'month', 'De bestuurswissel eind 1973. Een pas aangetreden bestuur wordt gefeliciteerddoor oud-bestuursleden. Einde en begin van een periode vol vergaderingen,organizeren, lezingen, commissies, dictaten, excursies en in 1974 de 68steDies Natalis. Een cylus die zich tot de 90ste Dies heeft voortgezet. Eencyclus die naast prachtige bestuurervaringen ook vaak ETV-vrieden &quot;voor hetleven&quot; maakt. Op naar de 100 jaar!', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(110, NULL, '', '', '000000', 0, '1974-04-01', 'month', '1974-12-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(111, NULL, '', '', '000000', 0, '1974-12-01', 'month', '1975-03-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(112, NULL, '', '', '000000', 0, '1975-03-01', 'month', '1975-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(113, NULL, '', '', '000000', 0, '1975-09-01', 'month', '1975-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(114, NULL, '', '', '000000', 1, '1975-11-01', 'month', '1976-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(115, NULL, '', '', '000000', 0, '1976-11-01', 'month', '1977-02-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(116, NULL, '', '', '000000', 0, '1977-02-01', 'month', '1977-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(117, NULL, '', '', '000000', 0, '1977-11-01', 'month', '1978-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(118, NULL, '', '', '000000', 0, '1979-04-01', 'month', '1980-04-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(119, NULL, '', '', '000000', 0, '1980-04-01', 'month', '1980-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(120, NULL, '', '', '000000', 1, '1980-10-01', 'month', '1981-05-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(121, NULL, '', '', '000000', 0, '1981-05-01', 'month', '1981-11-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(122, NULL, '', '', '000000', 0, '1981-11-01', 'month', '1982-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(123, NULL, '', 'De oplossing is het probleem', '000000', 0, '1982-09-01', 'month', '1983-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(124, NULL, '', '', '000000', 0, '1983-09-01', 'month', '1984-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(125, NULL, '', '', '000000', 0, '1984-09-01', 'month', '1985-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(126, NULL, '', '', '000000', 1, '1985-10-01', 'month', '1986-10-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(127, NULL, '', '', '000000', 0, '1986-10-01', 'month', '1987-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(128, NULL, '', '', '000000', 0, '1987-09-01', 'month', '1988-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(129, NULL, '', '', '000000', 0, '1988-09-01', 'month', '1989-09-01', 'month', '[b]Buitenlandse contacten[/b]\r\n\r\nSinds jaar en dag is het traditie dat de Electrotechnische Vereeniging veel contacten heeft met de studie verenigingen van universiteiten en hogescholen uit heel Nederland. De ETV en dus ook het bestuur trekt veel profijt van dit netwerk van studieverenigingen, maar het typische is, dat niemand precies schijnt te weten hoe dit netwerk ontstaan is. Vele verhalen doen hierover de ronde. In werkelijkheid is echter het volgende gebeurd:\r\n\r\nIn september ''88 trad een fris en daadkrachtig bestuur aan. Er moest dat bestuursjaar namelijk veel gebeuren. Na de Kojac-reis diende de Switch-reis zich al aan. Het ETV periodiek Pro-ETIR moest goed op poten gezet worden en voor het Lustrum van 1991 moesten de eerste plannen gemaakt worden.Op zich is dit met goede inzet van de ETV-ers goed te doen. Het vaarwater van de ETV werd echter behoorlijk gedwarsboomd door de toenmalige minister van onderwijs, die de éne bezuiniging na de andere doorvoerde. De basisbeurs werd kleiner en kleiner en de studie een stuk zwaarder. Nu is een enkele tegenslag van overheidswege voor een vereniging natuurlijk geen doodslag, maar zou het wel bij deze enkele tegenslag blijven of zou de overheid door gaan met het uitmelken van universiteiten en studenten?\r\n\r\nIn het kersverse bestuur bevonden zich gelukkig nogal wat strategen en visionairs die ver vooruit konden kijken en zij concludeerden over de maatregelen van de minister: ''Hier zal het niet bij blijven''. Maar hoe kunnen wij er dan voor zorgen dat de ETV en de gehele sfeer daaromheen voor de TU en natuurlijk de studenten behouden blijft? Na ampele beraadslagingen zag het bestuur in, dat in tijden van nood men de handen inéén zal moeten slaan om tegen de onderdrukker verzet te kunnen blijven bieden.\r\n\r\nDit gezegd hebbende werd rond gekeken naar andere onderdrukte studieverenigingen waarmee overleg en wellicht acties of activiteiten gepland en uitgevoerd konden worden.\r\n\r\nNu is het bekend dat de Electrotechnische Vereeniging in Delft op eenzame hoogte staat. Kijk om je heen en je ziet helemaal niets. Kijk langer en geconcentreerder en langzaam beginnen uit de mist allerlei vage studievereniginkjes op te duiken. Moest de ETV hiermee in zee? Was dit dan tegelijk het voorland van de ETV? De bestuurlijke strategen besloten van niet en dus werd verder gekeken. Nu zijn de contacten met de dochters van de ETV in Eindhoven en Twente goed, maar iedereen zal onderschrijven dat daar de oplossing niet lag. Nee, gekeken moest worden naar studieverenigingen vergelijkbaar met de ETV en in een soortgelijke positie. Duidelijk is dat je die dus niet zomaar even vindt!\r\n\r\nNu beschikte het bestuur 88-89 over twee solide bestuurswagens (zie foto). Hiermee lag dus heel Nederland voor de ETV (en dus het bestuur) open. Direct werd dan ook het plan opgevat om studieverenigingen in andere steden aan te schrijven om het potentieel als partner van de ETV te beoordelen. De brief werd dezelfde dag nog opgesteld en verzonden.\r\n\r\nUit de reacties bleek dat het bestuur niet alleen over strategen beschikte maar ook over goede marketeers, want op de eerste mailing van 20 stuks kwam een respons van maar liefst 60%! Bij deze respondenten zaten clubs als de Confrerie (Hogere Hotelschool), de JFR (juristen uit Rotterdam), BIL (bestuurskunde uit Leiden), de Geologische vereniging uit Utrecht en nog vele anderen.\r\n\r\nZo was het eerste contact gelegd en binnen de kortste keren werd de ETV uitgenodigd om eens te komen praten. Vaak viel dit samen met een receptie, diesviering, feest of gala, zodat niet alleen met het bestuur, maar ook uitvoerig met de leden van die studievereniging van gedachten kon worden gewisseld. Vaak moet je er namelijk wat dieper induiken om te bepalen wat voor vlees je in de kuip hebt!\r\n\r\nOp deze manier werden dat bestuursjaar 17 verenigingen bezocht, maar geen kon op een historie bogen die ook maar enigszins in de buurt kwam van die van de ETV. Zodoende is het, dat het bestuur heden ten dage nog altijd op zoek is naar een juiste partner. Deze zoektocht wordt alleen maar intensiver de visionairs uit het bestuur 88-89 gelijk hebben gekregen voor wat betreft het ministrieel geweld: ''Daar bleef het niet bij''.\r\n\r\nSommigen zullen blijven beweren dat de contacten van de ETV in andere steden slechts door een zucht naar feesten, gezelligheid en drank is ontstaan, maar éénieder die dit gelezen heeft weet wel beter!\r\n\r\nHet bestuur 88-89.', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(130, NULL, 'Fortiter in re, suaviter in modo', '', '000000', 0, '1989-09-01', 'month', '1990-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(131, NULL, 'Audax omnia perpeti', '', '000000', 1, '1990-09-01', 'month', '1991-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(132, NULL, '', '', '000000', 0, '1991-09-01', 'month', '1992-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(133, NULL, '', '', '000000', 0, '1992-08-31', 'month', '1993-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(134, NULL, '', '', '000000', 0, '1993-08-31', 'month', '1994-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(135, 123, '', '', 'ffa500', 0, '1994-08-31', 'month', '1995-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(136, 124, '', '', '0000ff', 1, '1995-08-31', 'month', '1996-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(137, 125, 'Het \\"Stralende\\" Bestuur', '', 'ff0000', 0, '1996-08-31', 'month', '1997-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(138, 126, 'Het \\"Onvergankelijke\\" Bestuur', '', '008000', 0, '1997-08-31', 'month', '1998-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(139, 127, '', '', '00ced1', 0, '1998-08-31', 'month', '1999-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(140, 128, '', '', 'ffa500', 0, '1999-08-31', 'month', '2000-08-31', 'month', 'De foto''s die genomen worden met het ETVototoestel zijn normaal alleen te zien in de bestuurskamer. Soms is dat heel praktisch, want niet alle foto''s die door het jaar heen genomen worden zijn even vleiend. Toch zijn er ook foto''s die wel voor publikatie geschikt zijn. Een aantal daarvan staan hieronder, voorzien van commentaar.', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(141, 129, '', '', '0000ff', 1, '2000-08-31', 'month', '2001-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(142, 130, 'Het \\"Veelzijdige\\" Bestuur', '', '808080', 0, '2001-08-31', 'month', '2002-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(143, 131, 'Het Vernieuwende Bestuur', '', 'ffff00', 0, '2002-08-31', 'month', '2003-08-31', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(144, 132, 'Het Vooruitstrevende Bestuur', 'Life can only be understood backwards, but it must be lived forwards.', 'ffa500', 0, '2003-08-31', 'month', '2004-09-14', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(145, 133, 'Het Voorzienende Bestuur', 'Firmior quo paratoir', '00bfff', 0, '2004-09-14', 'day', '2005-09-13', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(146, 134, 'Het Bruisende Bestuur', 'It\\''s not the position you stand, but the direction in which you look.', 'ffd700', 1, '2005-09-13', 'day', '2006-09-12', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(147, 135, 'Het Ontdekkende Bestuur', 'Logic will get you from A to B. Imagination will take you everywhere.', '7fffd4', 0, '2006-09-12', 'day', '2007-09-11', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(148, 136, 'Het Verlichtende Bestuur', 'Nil  Volentibus Arduum', 'ff0000', 0, '2007-09-11', 'day', '2008-09-09', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(149, 137, 'Het Verfrissende Bestuur', 'Non nobis solum nati sumus', '00ff00', 0, '2008-09-09', 'day', '2009-09-09', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(150, 138, 'Het Uitnodigende Bestuur', 'Bonus vir semper tiro', '800080', 0, '2009-09-09', 'day', '2010-09-07', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(151, 139, 'Het Ondernemende Bestuur', 'Aude Audenda', '0000ff', 1, '2010-09-07', 'day', '2011-09-13', 'day', 'Liever een Lustrumbestuur dan een doodgewoon Bestuur.\r\n\r\n', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(152, 140, 'Het Originele Bestuur', 'Alio sub sole virescetis', 'ffa500', 0, '2011-09-13', 'day', '2012-09-12', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(153, 141, 'Het Dynamische Bestuur', 'Aut viam inveniam, aut faciam', '00bce4', 0, '2012-09-12', 'day', '2013-09-10', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(154, 142, 'Het innoverende Bestuur', 'Omnia possunt, etiamsi ne aliquid posset', '006600', 0, '2013-09-10', 'day', '2014-09-09', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(155, 143, 'Het Resolute Bestuur', 'Pedes in terra ad sidera visus', '00414b', 0, '2014-09-09', 'day', '2015-09-08', 'day', 'De bestuurskleur is donkerchill, net als de bak', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(156, 144, 'Het Transparante Bestuur', 'quod si non esset, quale esse debeat', '00a79d', 1, '2015-09-08', 'day', '2016-09-09', 'day', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(157, 145, 'Het Verbindende Bestuur', 'Concordia res parvae crescunt', 'e78231', 0, '2016-09-09', 'day', '2017-09-01', 'month', '', '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `board_members`
--

CREATE TABLE `board_members` (
  `person_id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `function_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `function_number` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `board_members`
--

INSERT INTO `board_members` (`person_id`, `board_id`, `function_name`, `function_number`, `created_at`, `updated_at`) VALUES
(2061, 156, 'Commissaris Internationale Betrekkingen & Vice-President', 6, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2138, 157, 'President', 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2149, 157, 'Thesaurier', 3, '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `board_pictures`
--

CREATE TABLE `board_pictures` (
  `id` int(11) NOT NULL,
  `board_id` int(11) NOT NULL,
  `priority` int(3) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `board_pictures`
--

INSERT INTO `board_pictures` (`id`, `board_id`, `priority`, `description`, `file_name`, `created_at`, `updated_at`) VALUES
(1, 94, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2, 96, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(3, 96, 1, 'President aan het woord', '06zijqk6.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4, 96, 2, 'ETV-vlag op Kanaalweg 2b, het vroegereElektrogebouw.', 'gsgrnwum.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(5, 98, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(6, 104, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(7, 105, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(8, 108, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(9, 109, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(10, 114, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(11, 117, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(12, 118, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(13, 120, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(14, 122, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(15, 123, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(16, 124, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(17, 125, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(18, 126, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(19, 127, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(20, 128, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(21, 129, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(22, 129, 1, '', '8889.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(23, 130, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(24, 131, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(25, 132, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(26, 133, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(27, 134, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(28, 135, 0, '', 'default.gif', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(29, 136, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(30, 137, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(31, 138, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(32, 138, 1, '', 'bestuur126 2e auto kapot.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(33, 138, 2, '', 'bestuur126 akciefeest1.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(34, 138, 3, '', 'bestuur126 akciefeest2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(35, 138, 4, '', 'bestuur126 akciefeest3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(36, 138, 5, '', 'bestuur126 arnbak1.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(37, 138, 6, '', 'bestuur126 arnbak2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(38, 138, 7, '', 'bestuur126 bestuur bij auto.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(39, 138, 8, '', 'bestuur126 bestuur bij its.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(40, 138, 9, '', 'bestuur126 bestuur net geinstalleerd.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(41, 138, 10, '', 'bestuur126 bijdekroes.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(42, 138, 11, '', 'bestuur126 bolsexcursie.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(43, 138, 12, '', 'bestuur126 dieseten.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(44, 138, 13, '', 'bestuur126 dieseten2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(45, 138, 14, '', 'bestuur126 dieseten3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(46, 138, 15, '', 'bestuur126 diesshit.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(47, 138, 16, '', 'bestuur126 excursielucent.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(48, 138, 17, '', 'bestuur126 galaleuven.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(49, 138, 18, '', 'bestuur126 galathor.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(50, 138, 19, '', 'bestuur126 jabouitreiking1.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(51, 138, 20, '', 'bestuur126 jabouitreiking3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(52, 138, 21, '', 'bestuur126 jabouitreiking2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(53, 138, 22, '', 'bestuur126 maxwelluitreiking.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(54, 138, 23, '', 'bestuur126 mfls.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(55, 138, 24, '', 'bestuur126 vissen.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(56, 138, 25, '', 'bestuur126 wisselingsdiner.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(57, 139, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(58, 139, 1, '', 'consfoto127.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(59, 140, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(60, 140, 1, 'Om te beginnen de kwartjesavond. Het was weer een groot feest...', 'bestuur128 kwartjesavond.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(61, 140, 2, '...waar sommigen niet genoeg van konden krijgen...', 'bestuur128 mee naar huis.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(62, 140, 3, '...en ook de CoCo vond het héééél gezellig.', 'bestuur128 slimme deel coco.jpg', '2016-11-28 16:21:13', '2016-11-30 13:45:33'),
(63, 140, 4, 'Na het feesten volgt het opruimen. Ook goed voor de integratie met het personeel van de faculteit.', 'bestuur128 giessen en ed in e-kafee.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(64, 140, 5, 'Dan een foto van een ander feestje, oftewel: het Bestuur in gala modus.', 'bestuur128 bestuur in gala modus.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(65, 140, 6, 'Een fotootje van de bestuurskamer de dag na de wisseling; geheel versierd door het vorige bestuur. (Ja, dat is inderdaad een vijver, met vissen en een fontein en ja, dat zijn ook shredder-uitwerpselen daar op de vloer...', 'bestuur128 versierde bestuurskamer.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(66, 140, 7, '...waarin de thesaurier zich uitstekend vermaakt.', 'bestuur128 boer vermaakt zich.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(67, 140, 8, 'Dan nog deze foto van twee indrukwekkende automobielen: een mooie (voor de kijker links) en een lelijke (voor de kijker rechts).', 'bestuur128 mooie auto (links) en lelijke auto (rechts).jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(68, 141, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(69, 142, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(70, 143, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(71, 143, 1, 'Het 131e Bestuur der Electrotechnische Vereeniging wenste U prettige feestdagen en een Vernieuwend 2003', '131-kerst.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(72, 143, 2, 'Het Regelende Bestuur tijdens het Gala van het VUGS op de Pier in Scheveningen op 12 oktober', 'bestuur131vugs.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(73, 143, 3, 'Het Regelende Bestuur met de geregelden', '131-vugs.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(74, 143, 4, 'De enige fatsoenlijke mensen in de Efteling op 3 november die wel een foto bij Kim kopen.\nMede mogelijk gemaakt door de MAKRO.', 'bestuur131efteling.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(75, 143, 5, 'Twee, Drie en Vier uit hun dak tijdens het Alcmaeon feestje "Paars II"', '131-2_3en4.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(76, 143, 6, 'Maar ook Eén en Vijf weten zich prima te vermaken...', '131-1en5.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(77, 143, 7, 'De bestuursvrouw probeert met ritmische bewegingen zijn secretaris te verleiden tot het meedoen aan zijn paringsdans.', '131-paaldansen.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(78, 143, 8, 'Tijdens het ouderrondje bezochten wij de Tapperij den Olifant in Apeldoorn. De oude stamkroeg van Robers.', '131-olifant.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(79, 144, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(80, 144, 1, 'Het 132e Bestuur brengt gezelligheid in Twente', '132-constitutiescintilla.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(81, 144, 2, '', '132_faculteit_ster_staf.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(82, 144, 3, 'Het Bestuur tijdens de constitutieborrel van de MFVU', 'bestuur132mfvuconst.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(83, 145, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(84, 145, 1, 'Een prachtig uitzicht op de Grote Markt', 'bestuur133_2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(85, 145, 2, 'Het 133e Bestuur op het IFF', 'bestuur133iff.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(86, 145, 3, 'Het Bestuur is kennis aan het maken met Wageningen', 'bestuur133wageningen.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(87, 145, 4, 'Het Bestuur is hard aan het integreren met Pardoes', 'bestuur133_pardoes.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(88, 146, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(89, 146, 1, '', 'lustrumbestuur20_2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(90, 146, 2, '', 'lustrumbestuur20_3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(91, 147, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(92, 147, 1, 'Algemene Ledenvergadering', '135_2.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(93, 147, 2, 'Traditioneel monitor aanbieden', '135_3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(94, 148, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(95, 148, 1, 'Algemene Ledenvergadering', '136-av.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(96, 148, 2, 'Het Bestuur op het gala van Alcmaeon en Helix', 'gala136.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(97, 148, 3, 'Bestuursbak - verlengde Mercedes W123, 240D', 'Bak136.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(98, 149, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(99, 149, 1, 'Het Bestuur in klassieke setting.', 'Portret.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(100, 149, 2, 'Bij de installatie kreeg het Bestuur van het zojuist afgetreden Bestuur een nieuw baliebord aangeboden.', 'PICT0594.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(101, 149, 3, 'Het Interfacultair Feest, met als thema Circus, en als act DJ José, was als vanouds een erg gezellige avond.', 'P9250021.JPG', '2016-11-28 16:21:13', '2016-11-30 13:44:51'),
(102, 149, 4, 'Met succes werd de pose van de welbekende lullo''s geïmiteerd in de /Pub.', 'PA130025.JPG', '2016-11-28 16:21:13', '2016-11-30 13:45:01'),
(103, 149, 5, 'Het Bestuur reikt de traditionele ETV-stoppentester uit aan een zojuist benoemde professor.', 'DSC_0244.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(104, 149, 6, 'Op schiphol werd op traditionele wijze een goede reis gewenst aan de Is real study tour-deelnemers.', 'IsReal_foto_010.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(105, 149, 7, 'Door de enorme groep ETV''ers had de galafotograaf op het Alcmaeongala z''n groothoeklens nodig.', 'Foto7.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(106, 149, 8, 'Het Bestuur heeft ook in curlen de nodige vaardigheden opgedaan.', 'P1190458.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(107, 149, 9, 'Ook de klusvaardigheden werden niet geschuwd toen aan de Scrapheap Challenge van dochtertje Priscilla werd deelgenomen.', 'P1310137.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(108, 149, 10, 'Gezelligheid tijdens het gala van MFVU.', 'P4090145.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(109, 149, 11, 'Echte bikkels die deelnamen aan het paintballen tijdens de Diesweek.', 'P5130572.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(110, 149, 12, 'Lekker weer maakte het zeilweekend tot een zeer groot succes.', 'P1000925.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(111, 149, 13, 'Het Dagelijks Bestuur in de droomvlucht.', 'P1000157.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(112, 149, 14, 'Het commissariaat in de droomvlucht.', 'P1000153.JPG', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(113, 149, 15, 'Onder strenge leiding van de Commissaris Extern werd één van de vakantiedagen creatief ingevuld, met veel bekijks tot gevolg.', 'P1000405.JPG', '2016-11-28 16:21:13', '2016-11-30 13:45:17'),
(114, 150, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(115, 151, 0, '', 'default.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(116, 151, 1, 'Het 139e Bestuur net geïnstalleerd.', 'Bestuur2.jpg', '2016-11-28 16:21:13', '2016-11-30 13:43:06'),
(117, 151, 2, 'Het Bestuur met kerst.', 'Bestuur3.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(118, 151, 3, 'De Bak.', 'Bestuur4.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(119, 152, 0, '??', 'default.jpg', '2016-11-28 16:21:13', '2016-11-30 10:53:07'),
(120, 152, 1, 'Het originele Bestuur na hun installatie tijdens de JV', 'bestuur1.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(121, 152, 2, '??', 'bestuur2.jpg', '2016-11-28 16:21:13', '2016-11-30 10:53:22'),
(122, 153, 1, '', 'bestuur.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(123, 154, 1, '', 'bestuur.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(124, 154, 2, 'Het innoverende Bestuur tijdens het ORAS lustrumgala', '14221422.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(125, 154, 3, 'Het innoverende kerstkaartje', '142214221422.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(126, 154, 4, 'De Baron', '1422142214221422.jpg', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(127, 155, 0, 'Foto van het Resolute Bestuur der Electrotechnische Vereeniging', 'bestuur.png', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(128, 156, 0, 'Bestuursfoto', 'bestuur.png', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(256, 157, 1, '', 'G36VlugoEK-IlTwgmC9xhJTXBbYvFIqe.jpg', '2016-11-28 17:08:45', '2016-11-29 08:06:14'),
(269, 157, 2, 'Kerstfoto', 'KKaWKO8U0e4uBy0OhR7FP685kz7-vZ7l.jpg', '2016-11-29 14:48:32', '2016-11-29 14:48:35'),
(270, 156, 1, '', 'jDe4A8Cv8KCA7TJuiZ_yFmpk8_6XNFiA.jpg', '2016-12-15 18:44:02', '2016-12-15 18:44:41');

-- --------------------------------------------------------

--
-- Table structure for table `committees`
--

CREATE TABLE `committees` (
  `id` int(11) NOT NULL,
  `short_name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('normal','chapter','fake') COLLATE utf8mb4_unicode_ci NOT NULL,
  `has_image` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `committees`
--

INSERT INTO `committees` (`id`, `short_name`, `long_name`, `email`, `description`, `type`, `has_image`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'AkCie', 'Aktiviteitencommissie', NULL, 'De AkCie, kort voor Aktiviteitencommissie, is een commissie bestaande uit eerstejaars, die gedurende het hele jaar leuke activiteiten voor iedereen organiseert. Denk hierbij bijvoorbeeld aan filmmiddagen, borrels, of een middag karten.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2, 'Archive Committee', 'Archive Committee', NULL, 'This committee is filled with former board members (mostly the secretaries). The committie is in charge of keeping the rich archive organised and up to date.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:13:52'),
(3, 'BarCo', 'Bar Committee', NULL, 'Every Thursday evening it is ETV evening in the /pub. To make sure that every guest has a perfectly tapped beer in front of him there is a large group of ETV members active as bartender. There can''t be enough bartenders so if you are interested don''t be shy to tell the Board.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:18:22'),
(4, 'CoCo', 'Computer Committee', NULL, 'De Computercommissie, kortweg CoCo, is altijd druk in de weer om de digitale speeltuin van de ETV op zeer hoog niveau te houden. Zij is verantwoordelijk voor het functioneren van alle computers die ons eigen netwerk rijk is, maar ook het onderhoud aan de servers dat hiermee gepaard gaat. Heb jij verstand van computers en netwerken, of wil je dit krijgen? Kom dan vooral eens kijken in ons commissiehok!', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:09:08'),
(5, 'Diescommissie', 'Diescommissie', NULL, 'Elk jaar wordt onze vereniging een jaartje ouder. Dit laten wij nooit ongemerkt voorbij gaan. Een gehele week vol activiteiten wordt daarom ieder jaar neergezet door de Diescommissie.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:27:13'),
(6, 'EOW Committee', '"Elektro Ontvangst Weekend" Committee', NULL, 'Om nieuwe studenten wegwijs te maken in het Delftsche en om hen kennis te laten maken met elkaar en de ETV, wordt ieder jaar het Elektro Ontvangst Weekend (EOW) georganiseerd. De commissie, volledig gevuld door eerstejaars, is verantwoordelijk voor alle aspecten van dit mooiste weekend van het jaar.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:09:50'),
(7, 'Electrip Committee', 'Electrip Committee', NULL, 'Ieder jaar zoekt een groep ETV''ers de elektrotechniek in het buitenland op. Tijdens een kleine studiereis wordt er een bestemming in Europa uitgekozen waar er een paar bedrijven bezocht worden. ', 'normal', 1, NULL, '2016-11-28 16:21:13', '2017-01-12 13:31:08'),
(8, 'EvaCie 1', 'Evaluation Committee 1', NULL, 'Dit is de Evaluatiecommissie voor het eerste jaar. De opleiding moet voor iedereen zo goed mogelijk zijn, en daarom wordt door middel van evaluaties met studenten het onderwijs onder de loep genomen. Zie jij problemen in je eerste jaar? Schroom dan niet om dit te melden! Dit kan via de Commissaris Onderwijs van de ETV (ook op deze website), of door middel van de EvaCie 1.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:20:39'),
(9, 'EvaCie 2', 'Evaluation Committee 2', NULL, 'Ook de vakken in het tweede jaar worden nauwgezet gecontroleerd door studenten en docenten. Geef jij graag je mening om het onderwijs nog beter te maken in het tweede jaar? Dan is de EvaCie 2 op zoek naar jou!', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:20:58'),
(10, 'EvaCie 3', 'Evaluatiecommissie 3', NULL, 'Ook het derde jaar bevat wat te evalueren aspecten. Het eerste semester van het derde jaar bestaat uit de minor, maar daarna gaan de elektrovakken weer lekker verder. Ook deze worden uiteraard door studenten geëvalueerd.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(11, 'HoCo', 'Homepage Committee', NULL, 'Het ontwerpen en onderhouden van een website kost veel tijd. Vandaar dat een groep ETV''ers zich daar speciaal voor inzet. Heb jij ervaring met PHP, MySQL, HTML, HTML 5, CSS, CSS 3, Javascript, jQuery, AJAX, Notepad++, Web 1.0, Web 2.0, Sublime Text 2, Firefox, Chrome, Opera, Safari, Computers en WWW, en heb jij vooral geen ervaring met Flash, Internet Explorer, Frontpage, iframes, framesets, center en marquee?\r\n\r\nOf wil je dit krijgen, dan is er altijd nog wel plaats in de Homepagecommissie.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:13:01'),
(12, 'Jabo', 'Jaarboekcommissie', NULL, 'De Commissie tot Redactie van het 58ste Jaarboek der Electrotechnische Vereeniging, beter bekend als de Jabocommissie. Het is aan deze commissie om een heel ETV-jaar te documenteren, en deze verhalen tot een boek te verwerken.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2017-01-11 11:40:10'),
(14, '"Klushok" Committee', '"Klushok" Committee', NULL, 'Het ETV-domein kent een bijzondere plek: het klushok. Iedereen die iets te klussen heeft, maar thuis niet beschikt over de benodigde materialen, kan hier altijd terecht om te werken. De klushokcommissie zet zich in om deze ruimte altijd netjes en gebruiksklaar te houden. Daarnaast zorgt zij ervoor dat er altijd voldoende elektronische componenten (tegen zeer lage prijs!) beschikbaar zijn.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:14:59'),
(15, 'Kobus Kuch Committee', 'Kobus Kuch Committee', NULL, 'Iedere derde dinsdag van de maand wordt er gezellig in de binnenstad geborreld in het gezelligste café van Delft: de Kobus Kuch. ''s Winters binnen en ''s zomers lekker op het terras. Zet het dus direct in je agenda: elke derde dinsdag van de maand, Kobus Kuch! Vanaf 22:00 op de Beestenmarkt 1.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:13:40'),
(16, 'Maxwell Committee', 'Maxwell Committee', NULL, 'Viermaal per jaar kun je als lid van de ETV een nieuwe editie van de Maxwell op je deurmat verwachten. Dit tijdschrift wordt gemaakt door een groep enthousiaste studenten, die zich inzet om voor iedere Maxwell voldoende artikelen te verzamelen en deze vervolgens grafisch perfect in elkaar te zetten. Extra handen zijn hier altijd welkom, dus heb jij journalistieke ambities, aarzel dan niet, en laat je interesse blijken bij het Bestuur!', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:14:52'),
(17, 'OOC', 'Onderwijs Overleg Commissie', NULL, 'De Onderwijs Overleg Commissie bestaat uit de huidige Commissaris Onderwijs en zijn voorgangers. Om te zorgen dat geen problemen over het hoofd worden gezien en als belangrijke bron voor advies komt deze commissie regelmatig bijeen om de Commissaris Onderwijs bij te staan.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:29:32'),
(18, 'Symposium Committee', 'Symposium Committee', NULL, 'Een symposium is een dag of dagdeel vol interessante lezingen en discussies. De ETV organiseert af en toe een dergelijk symposium. Deze commissie is verantwoordelijk voor de organisatie van het gehele evenement.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:38:01'),
(19, 'Zeilweekendcommissie', 'Zeilweekendcommissie', NULL, 'Jaarlijks wordt er door de Zeilweekendcommissie een prachtig zeilweekend georganiseerd waar de open lucht, water, boten, veel gezelligheid en het genot van een pintje tezamen komen.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(20, 'HuCo', 'Corporate Design Committee', NULL, 'Sinds jaar en dag wordt getracht om de ETV een professionele uitstraling te geven. Eén van de aspecten van een nette uitstraling is een uniforme huisstijl, die overal in te herkennen is. De Huco, kortweg Huisstijlcommissie, houdt zich bezig met het ontwikkelen van deze huisstijl.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:19:11'),
(21, 'EESTEC', 'EESTEC Committee', NULL, 'Bijna elk jaar wordt er bij de ETV een EESTEC-commissie aangesteld om een week lang durende workshop te organiseren voor mensen uit het buitenland. Deze workshop bestaat uit zowel uit academische activiteiten, bijvoorbeeld excursies naar bedrijven of gezellige activiteiten, zoals uitgaan en oudhollandse spelletjes spelen.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:09:21'),
(22, 'KVC', 'Financial Verification Committee', NULL, 'Om te zorgen dat alle financiële zaken binnen de ETV correct gebeuren, zijn de commissieleden van deze wijze commissie altijd alert. Zij controleren alle financiële documenten (begrotingen, exploitaties) uitvoerig, alvorens deze op de Algemene Vergadering worden gepresenteerd. ', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-12-09 14:21:55'),
(23, 'Maxwell Realisatie Commissie', 'Maxwell Realisatie Commissie', NULL, 'Het drukken van een tijdschrift kost veel geld. Om dit kostenplaatje financieel rond te krijgen zet de Commissaris Extern van het Bestuur zich extra hard in, om alles pagina''s in full color te kunnen blijven vullen. Omdat de afronding van deze taak pas na een academisch jaar gebeurd, wordt de Commissariss Extern officieel in deze commissie geïnstalleerd.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:40:25'),
(24, 'DTC', 'Dispuut Telecommunicatie', NULL, 'Het dispuut voor Telecommunicatie.', 'chapter', 0, NULL, '2016-11-28 16:21:13', '2016-11-29 13:41:44'),
(25, 'Sterkstroomdispuut', 'Sterkstroomdispuut', NULL, 'Welkom op de pagina van het Sterkstroomdispuut der Electrotechnische Vereeniging.\r\n\r\nHet Sterkstroomdispuut (SSD) is het dispuut voor studenten en medewerkers van de afdeling Electrical Sustainable Energy.\r\nHet dispuut behartigt sinds 1964 de belangen van de sterkstroomstudent.\r\nHet bestuur van het SSD bestaat afwisselend uit studenten en promovendi van de afdeling welke allen hebben deelgenomen aan de master "Electrical Power Engineering". Elk jaar organiseert het Sterkstroomdispuut excursies naar bedrijven in haar vakgebied, een kerstlunch en verschillende borrels in de /Pub.\r\n\r\nHet bestuur hoopt je tegen te komen op één van haar activiteiten!\r\n\r\nMartijn Janssen\r\n\r\nPresident der Sterkstroomdispuut', 'chapter', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:40:34'),
(26, 'Facultaire StudentenRaad', 'Facultaire StudentenRaad', NULL, 'De facultaire studentenraad.', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(27, 'Lustrum', 'Lustrum Committee', NULL, 'Elke lustrumjaar viert onze vereniging dat ze weer vijf jaar ouder is geworden. De Lustrumcommissie organiseert het hele jaar door activiteiten waar voor iedereen wel wat leuks tussen zit.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:19:28'),
(28, 'Lustrumgala', 'Lustrumgalacommissie', NULL, 'Elk lustrumjaar organiseert de Lustrum Galacommissie een gala. Een mooie locatie, nette kleding en veel gezelligheid zorgt geheid voor een onvergetelijke avond.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(29, 'Lustrumstunt', 'Lustrumstunt Committee', NULL, 'De vereniging laat haar lustra niet onopgemerkt voorbij gaan. Daarom is er de Lustrum Stuntcommissie om elke vijf jaar een mooie stunt neer te zetten.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-30 12:14:29'),
(30, 'Study Tour Committee', 'Study Tour Committee', NULL, 'Om de zoveel jaar wordt er een reis georganiseerd vanuit de ETV. Deze reis gaat dan naar een ver land waar een groep elektrostudenten drie à vier weken langs bedrijven gaat en veel gezelligheid deelt.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:17:10'),
(31, 'Recruitment days', 'Recruitment days commissie', NULL, 'Elk jaar organiseert de ETV de EWI Wervingsdagen waar studenten van faculteit EWI in contact komen met het bedrijfsleven. Kijk voor meer informatie op de website.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:41:04'),
(32, 'FeeCie', 'Party Committee', NULL, 'De Feestcommissie organiseert gave feesten op eigen houtje, of samen met een andere vereniging.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:12:51'),
(33, 'IEEE', 'IEEE', NULL, 'IEEE Student Branch in Delft.', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(34, '26 Maart-commissie', '26 Maart-commissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(35, 'Avionica', 'Avionica Dispuut', NULL, '', 'chapter', 0, NULL, '2016-11-28 16:21:13', '2016-11-29 13:41:48'),
(36, 'Bedrijvencommissie', 'Bedrijvencommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(37, 'BMT', 'BMT', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(39, 'CEC', 'Culturele Evenementencommissie', NULL, 'De CEC, kort voor Culturele Evenementen-Commissie, is een commissie bestaande uit ouderejaars, die het hele jaar leuke evenementen voor iedereen uitzoeken. Denk hierbij bijvoorbeeld aan theater, film en concertbezoeken.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(40, 'CIC', 'CIC', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(41, 'COC', 'COC', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(42, 'Dispuut', 'Dispuut', NULL, '', 'chapter', 0, NULL, '2016-11-28 16:21:13', '2016-11-29 13:41:52'),
(43, 'Dtour', 'Dtourcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(44, 'Eeuwboek', 'Eeuwboekcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(45, 'Eeuwgala', 'Eeuwgalacommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(46, 'Gala', 'Galacommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(47, 'GATEWAY', 'GATEWAY-Commissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(48, 'Ing.', 'Ing.', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(49, 'LAN', 'LAN Committee', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-12-21 08:01:21'),
(50, 'LeCo', 'Lezingencommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(51, 'Maxwell Redactie', 'Maxwell Redactie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(52, 'Monitour', 'Monitourcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(53, 'Ouderdag', 'Ouderdagcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(54, 'Peco', 'The Illustrious Society of Bedels', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-30 12:16:24'),
(55, 'Perio', 'Perio', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(56, 'Perio Acq', 'Perio Acq', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(57, 'Perio Rea', 'Perio Rea', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(58, 'Perio Red', 'Perio Red', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(59, 'Promo', 'Promo', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(61, 'Saneringscommissie', 'Saneringscommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(62, 'States', 'Statescommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(63, 'Verstelregel', 'Verstelregel', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(64, 'FilmCo', 'Filmcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(65, 'RaCie', 'Rally Committee', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:16:54'),
(66, 'EOW-Mentoren', 'EOW-Mentoren', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(67, 'Location Committee', 'Location Committee', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:14:15'),
(71, 'wAkCie ''12-''13', 'Winteractiviteitencommissie 2012-2013', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(72, 'zAkCie ''12', 'Zomeractiviteitencommissie 2012', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(73, 'wAkCie ''11-''12', 'Winteractiviteitencommissie 2011-2012', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(74, 'zAkCie ''11', 'Zomeractiviteitencommissie 2011', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(75, 'wAkCie ''10-''11', 'Winteractiviteitencommissie 2010-2011', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(76, 'zAkCie ''10', 'Zomeractiviteitencommissie 2010', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(77, 'EOW30', '30e EOW-commissie', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:41:44'),
(78, 'EOW29', '29e EOW-commissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(79, 'EOW28', '28e EOW-commissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(80, 'FeeCie 1', '1e Feestcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(82, 'FeeCie 2', '2e Feestcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(83, 'Sympo 2012', 'Future Computing Symposiumcommissie', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:41:53'),
(84, 'WiSpo', 'ETV-Wintersport', NULL, 'De organiserende commissie van de ETV-Wintersport', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(85, 'EOW-Mentoren 30e EOW', 'EOW-Mentoren 30e EOW', NULL, 'De mentoren van het 30e EOW', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(86, 'EOW-Mentoren 29e EOW', 'EOW-Mentoren 29e EOW', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(87, 'EOW-Mentoren 28e EOW', 'EOW-Mentoren 28e EOW', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(88, 'WiSpo1', '1e ETV-Wintersport', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(89, 'WiSpo2', '2e ETV-Wintersport', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(90, 'JaBo52', '52e Jaarboekcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(91, 'EOW27', '27e EOW-commissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(92, 'Henk''s Stroeve Commissie', 'Henk''s Stroeve Commissie', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:42:01'),
(94, 'EOW 31', '31e EOW-commissie', NULL, 'Deze commissie organiseert het 31ste Electro Ontvangstweekend.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:42:09'),
(95, 'zAkCie ''13', 'Zomeractiviteitencommissie 2013', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(96, 'EOW-Mentoren 31e EOW', 'EOW-Mentoren 31e EOW', NULL, '', 'fake', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(97, 'FeeCie', '3e Feestcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(98, 'Wispo', 'Ski Trip Committee', NULL, 'Ook dit jaar reist de ETV weer af naar de alpen om daar een skigebied onveilig te maken. ', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:17:44'),
(100, 'Sport', 'Sportcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(101, 'EESTEC LC', 'EESTEC LC Delft', NULL, 'EESTEC LC Delft', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:40:00'),
(103, 'WakCie', ' Winteractiviteitencommissie 2013-2014', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(104, 'WeeCo', 'Weekendcommissie', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(105, 'zAkCie', 'Zomeractiviteitencommissie 2014', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:42:49'),
(106, 'TapCo', 'Pianotap Committee', NULL, 'Verzorgt de pianotap en zorgt ervoor dat deze onderhouden wordt.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:19:42'),
(107, 'FEE', 'Female Electrical Engineers', NULL, 'Een commissie tot bevordering van de integratie van alle vrouwelijke leden!', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:43:13'),
(108, 'wAkCie ''14-''15', 'Winteractiviteitencommissie 2014-2015', NULL, 'Een commissie bestaande uit enthousiaste eerstejaars die in de koude wintermaanden activiteiten organiseert voor alle ETV''ers.', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-29 14:43:29'),
(109, 'zAkCie ''15', 'Zomeractiviteitencommissie 2015', NULL, 'Het wordt weer zonnig in Nederland, tijd voor zomerse activiteiten georganiseerd door deze commissie.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(110, 'Lustrumwintersport', 'Lustrumwintersportcommissie', NULL, 'Voor de vijfde keer op rij gaat de ETV naar de Franse Alpen.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(111, 'PACo', 'Personal Audio Committee', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:15:17'),
(112, 'WakCie ''15-''16', 'Winteractiviteitencommissie 2015-2016', NULL, '', 'normal', 0, NULL, '2016-11-28 16:21:13', '2017-01-31 16:27:54'),
(113, 'DiscusCie', 'DiscusCie', NULL, 'Om de discussie binnen de ETV aan te zwengelen is er een commissie tot stand gekomen om het gesprek aan te gaan.', 'normal', 0, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(115, 'ZakCie 2016', 'Summer Activities Committee 2016', NULL, '', 'normal', 1, NULL, '2016-11-28 16:21:13', '2016-11-30 12:18:05'),
(116, 'SET Dispuut', 'Delft Sustainable Energy Association', NULL, '', 'chapter', 0, NULL, '2016-11-28 16:21:13', '2016-11-29 13:41:35'),
(117, 'PhoCO', 'Photo Committee', NULL, '', 'fake', 0, NULL, '2017-01-09 09:17:23', '2017-01-09 09:17:23'),
(118, 'InterCom', 'Intermastertrack Committee', NULL, '', 'normal', 1, NULL, '2017-01-12 12:11:41', '2017-01-12 12:16:21'),
(119, 'wAkCie ''16-''17', 'Winteractivity Committee 2016-2017', NULL, '', 'normal', 0, NULL, '2017-01-31 16:28:46', '2017-01-31 16:28:46');

-- --------------------------------------------------------

--
-- Table structure for table `committee_members`
--

CREATE TABLE `committee_members` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `committee_id` int(11) NOT NULL,
  `installation` date DEFAULT NULL,
  `discharge` date DEFAULT NULL,
  `function_number` tinyint(1) DEFAULT NULL,
  `function_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `committee_members`
--

INSERT INTO `committee_members` (`id`, `person_id`, `committee_id`, `installation`, `discharge`, `function_number`, `function_name`, `created_at`, `updated_at`) VALUES
(159, 2061, 101, '2015-01-01', '0000-00-00', 1, 'Chairperson', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(162, 2138, 101, '2016-01-01', NULL, 1, 'Chairman', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(198, 2162, 108, '2014-01-01', '0000-00-00', 2, 'Secretaris', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(203, 2138, 109, '2015-01-01', '0000-00-00', 1, 'President', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(223, 1335, 11, '2010-01-01', NULL, 1, 'President', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(233, 2061, 11, '2016-01-01', NULL, 3, 'Commissaris Paul', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(234, 2138, 11, '2016-01-01', NULL, 6, 'Domme deel', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(235, 2149, 11, '2016-01-01', NULL, 7, 'Domme deel', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(236, 2162, 11, '2016-01-01', NULL, 4, 'Commissaris geen idee joh', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(237, 2061, 110, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(239, 2061, 111, '2015-01-01', NULL, NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(244, 2306, 112, '2015-01-01', '0000-00-00', 3, 'Thesaurier', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(360, 2149, 12, '2016-01-01', '2016-09-13', 5, 'Commissaris Lay-out', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(470, 2061, 15, '2016-01-01', NULL, 6, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(583, 2138, 18, '2016-01-01', NULL, 4, 'Commissaris Symposium', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(604, 2061, 19, '2014-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(900, 2138, 26, '2016-01-01', NULL, NULL, 'Regulations EE', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(926, 2061, 27, '2014-01-01', NULL, 1, 'President', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1080, 2061, 3, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1089, 2138, 3, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1094, 2061, 3, '2016-01-01', NULL, NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1095, 2149, 3, '2016-01-01', NULL, NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1105, 2138, 3, '2016-01-01', NULL, NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1161, 2061, 31, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1262, 2061, 4, '2015-01-01', '0000-00-00', NULL, 'Domme deel', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1448, 2306, 54, '2016-01-01', NULL, 6, 'Commissaris Monitor', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1556, 2306, 6, '2016-01-01', NULL, 2, 'Secretaris', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1558, 2162, 6, '2016-01-01', NULL, 4, 'Commissaris Logistiek', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1611, 2138, 67, '2016-01-01', NULL, NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1785, 2420, 8, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1941, 2138, 9, '2015-01-01', '0000-00-00', NULL, '', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1953, 2420, 9, '2016-01-01', NULL, 4, 'Vice-secretaris', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1956, 2306, 9, '2016-01-01', NULL, 9, 'Commissaris WeetIkVeel', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2017, 2306, 12, '2016-12-20', NULL, 1, 'President', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2026, 2061, 31, '2016-12-20', NULL, NULL, 'Supervising Organizer', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2029, 2138, 31, '2016-12-20', NULL, NULL, 'Secretary', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2037, 2420, 65, '2016-12-20', NULL, 1, 'President', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2046, 1335, 49, '2016-12-20', '2017-09-04', NULL, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_departments`
--

CREATE TABLE `faculty_departments` (
  `id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_employees`
--

CREATE TABLE `faculty_employees` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `room` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tu_phone` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_employee_departments`
--

CREATE TABLE `faculty_employee_departments` (
  `faculty_employees_id` int(11) NOT NULL,
  `faculty_departments_id` int(11) NOT NULL,
  `function` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `honorary_members`
--

CREATE TABLE `honorary_members` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `type` enum('evv','evb','erevoorzitter','lvv') COLLATE utf8mb4_unicode_ci NOT NULL,
  `installation` date NOT NULL,
  `discharge` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `alias`, `apply_time`) VALUES
('m000000_000000_base', '@app/migrations', 1480344951),
('m150417_090408_create_members_schema', '@app/modules/membermodels/migrations', 1480344951),
('m150825_124010_create_view', '@app/modules/membermodels/migrations', 1480344951),
('m160228_152713_alter_member_tables', '@app/modules/membermodels/migrations', 1480344951),
('m160228_161224_alter_members_persons_search', '@app/modules/membermodels/migrations', 1480344951),
('m160331_114500_members_persons_search_add_relevance_column', '@app/modules/membermodels/migrations', 1480344951),
('m160503_141152_member_debtor_id_to_debtor_code', '@app/modules/membermodels/migrations', 1480344951),
('m160613_161800_persons_search_fix_filtering_address_deleted_at', '@app/modules/membermodels/migrations', 1480344951),
('m160905_150903_update_persons_search', '@app/modules/membermodels/migrations', 1480344951),
('m160905_155209_create_queries_table', '@app/migrations', 1480344951),
('m160905_200110_create_persons_advanced_view', '@app/modules/membermodels/migrations', 1480344951),
('m161015_201025_add_options_for', '@app/modules/membermodels/migrations', 1480344951),
('m161015_230812_add_queries_group', '@app/migrations', 1480344951),
('m161017_200856_update_persons_advanced_view', '@app/modules/membermodels/migrations', 1480344951),
('m161125_165102_remove_person_pictures_taken_at', '@app/modules/membermodels/migrations', 1480344951),
('m161129_121248_add_committee_columns', '@app/modules/membermodels/migrations', 1480425470),
('m170709_154500_add_pending_changes_table', '@app/modules/membermodels/migrations', 1499774340);

-- --------------------------------------------------------

--
-- Table structure for table `normal_members`
--

CREATE TABLE `normal_members` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `registration` date NOT NULL,
  `deregistration` date DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `normal_members`
--

INSERT INTO `normal_members` (`id`, `person_id`, `type_id`, `registration`, `deregistration`, `created_at`, `updated_at`) VALUES
(45, 1335, 1, '2009-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(260, 2061, 1, '2013-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(292, 2138, 1, '2014-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(300, 2149, 1, '2014-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(306, 2162, 1, '2015-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(383, 2306, 1, '2015-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(453, 2420, 1, '2015-01-01', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `normal_member_types`
--

CREATE TABLE `normal_member_types` (
  `id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('bsc','msc','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `normal_member_types`
--

INSERT INTO `normal_member_types` (`id`, `name`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Bachelor', 'bsc', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2, 'Master', 'msc', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(3, 'Pre-master', 'other', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4, 'Schakeljaar', 'other', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(5, 'PhD', 'other', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(8, 'Sustainable Energy Technology', 'msc', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(9, 'Onbekend', 'other', '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(10, 'Embedded Systems', 'msc', '2016-11-28 17:13:27', '2016-11-28 17:13:27'),
(11, 'Electrical Engineering', 'bsc', '2016-11-28 17:46:41', '2016-11-28 17:46:41'),
(12, 'Electrical Power Engineering', 'msc', '2016-11-29 16:42:08', '2016-11-29 16:42:08'),
(13, 'Microelectronics', 'msc', '2016-11-30 16:20:38', '2016-11-30 16:20:38'),
(14, 'Biomedical Engineering', 'msc', '2016-12-02 08:10:21', '2016-12-02 08:10:21'),
(15, 'Electrical Engineering', 'msc', '2016-12-06 13:39:00', '2016-12-06 13:39:00'),
(16, 'Computer Engineering', 'msc', '2016-12-11 14:52:23', '2016-12-11 14:52:23');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `for_persons` tinyint(1) NOT NULL,
  `for_associations` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `name`, `description`, `for_persons`, `for_associations`, `created_at`, `updated_at`) VALUES
(1, 'Maxwell', 'Ter versturen van de periodiek', 1, 1, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(2, 'EESTEC Mail', 'Ter versturen van de mail over aankomende EESTEC-activiteiten', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(3, 'Bedrijvenmail', 'Ter versturen van de mail over aankomende Bedrijfsactiviteiten', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(4, 'Online opt-out', 'Of deze persoon niet online te vinden wil worden', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(5, 'Reünistendag', 'Of deze persoon uitgenodigd wilt worden voor de Reunistendag', 1, 0, '2016-11-28 16:21:14', '2016-11-30 15:44:13'),
(6, 'Jaarboek', 'Ter versturen van het jaarboek', 1, 1, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(7, 'Symposium', 'Of deze persoon informatie over het symposium wilt ontvangen', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(8, 'Gala', 'Of deze persoon een uitnodiging wilt ontvangen over het Gala', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(9, 'Kaartje', 'Ter versturen van een constitutie- of kerstkaartje', 1, 1, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(10, 'ETV-nieuwsbrief', 'Ter versturen van de algemene ETV-nieuwsbrief', 1, 1, '2016-11-28 16:21:14', '2016-11-28 15:28:01'),
(11, 'Feestjes', 'Ter versturen van een mail/update van aankomende feestjes', 1, 0, '2016-11-28 16:21:14', '2016-11-28 15:28:01');

-- --------------------------------------------------------

--
-- Table structure for table `option_association_links`
--

CREATE TABLE `option_association_links` (
  `association_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `option_association_links`
--

INSERT INTO `option_association_links` (`association_id`, `option_id`, `created_at`, `updated_at`) VALUES
(2, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(3, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(3, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(3, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(4, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(4, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(4, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(5, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(5, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(5, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(6, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(6, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(6, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(7, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(7, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(7, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(8, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(8, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(8, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(9, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(9, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(9, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(10, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(10, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(10, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(11, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(11, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(12, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(12, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(12, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(13, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(13, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(13, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(14, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(14, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(14, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(15, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(15, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(15, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(16, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(16, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(16, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(17, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(18, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(18, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(18, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(19, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(19, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(20, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(20, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(21, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(21, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(22, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(22, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(23, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(24, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(24, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(24, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(25, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(26, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(27, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(27, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(28, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(28, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(29, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(29, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(29, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(30, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(30, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(30, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(32, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(33, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(33, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(34, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(34, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(36, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(36, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(37, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(38, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(38, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(38, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(39, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(40, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(40, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(40, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(41, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(41, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(41, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(42, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(42, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(42, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(43, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(43, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(43, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(44, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(44, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(44, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(45, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(46, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(46, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(46, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(47, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(47, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(47, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(48, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(48, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(49, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(49, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(50, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(51, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(51, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(52, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(53, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(53, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(55, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(57, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(60, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(63, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(63, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(64, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(65, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(65, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(69, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(69, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(70, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(70, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(71, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(71, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(72, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(72, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(76, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(77, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(77, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(78, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(79, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(80, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(80, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(80, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(81, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(82, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(82, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(85, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(85, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(85, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(92, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(93, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(93, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(95, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(99, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(101, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(102, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(102, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(102, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(104, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(104, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(104, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(105, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(106, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(106, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(106, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(107, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(107, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(107, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(108, 6, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(108, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(109, 9, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(112, 9, '2016-12-21 14:12:02', '2016-12-21 14:12:02');

-- --------------------------------------------------------

--
-- Table structure for table `option_person_links`
--

CREATE TABLE `option_person_links` (
  `person_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `option_person_links`
--

INSERT INTO `option_person_links` (`person_id`, `option_id`, `created_at`, `updated_at`) VALUES
(1335, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1335, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1335, 3, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(1335, 6, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(1335, 7, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(1335, 8, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(1335, 10, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(1335, 11, '2016-11-29 09:54:12', '2016-11-29 09:54:12'),
(2061, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2138, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2138, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2138, 3, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2138, 5, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 6, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 7, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 8, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 10, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2149, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2149, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2149, 3, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2149, 10, '2016-11-28 15:42:43', '2016-11-28 15:42:43'),
(2162, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2162, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2162, 3, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2306, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2306, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2306, 3, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2420, 1, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2420, 2, '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2420, 3, '2016-11-28 16:21:14', '2016-11-28 16:21:14');

-- --------------------------------------------------------

--
-- Table structure for table `pending_changes`
--

CREATE TABLE `pending_changes` (
  `id` int(11) NOT NULL,
  `reference_id` int(10) DEFAULT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_model_id` int(10) DEFAULT NULL,
  `change_model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changes` text COLLATE utf8mb4_unicode_ci,
  `file_path` text COLLATE utf8mb4_unicode_ci,
  `resolved_by` int(10) DEFAULT NULL,
  `resolved_resolution` enum('accepted','rejected') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pending_changes`
--

INSERT INTO `pending_changes` (`id`, `reference_id`, `reference_type`, `change_model_id`, `change_model_type`, `change_type`, `changes`, `file_path`, `resolved_by`, `resolved_resolution`, `resolved_at`, `created_at`, `updated_at`) VALUES
(1, 1335, 'Person', 1335, 'Person', 'update', '{"sex":"other"}', NULL, NULL, 'accepted', '2017-07-11 17:53:43', '2017-07-11 15:49:23', '2017-07-11 15:53:43'),
(2, 1335, 'Person', 1079, 'PersonAddress', 'update', '[]', NULL, NULL, 'rejected', '2017-07-11 17:53:45', '2017-07-11 15:49:23', '2017-07-11 15:53:45'),
(3, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"Sjaars"}', NULL, NULL, 'accepted', '2017-07-11 17:53:40', '2017-07-11 15:53:29', '2017-07-11 15:53:40'),
(4, 1335, 'Person', 1079, 'PersonAddress', 'update', '[]', NULL, NULL, 'rejected', '2017-07-11 17:53:44', '2017-07-11 15:53:29', '2017-07-11 15:53:44'),
(5, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":""}', NULL, NULL, 'accepted', '2017-07-11 18:03:46', '2017-07-11 16:03:39', '2017-07-11 16:03:46'),
(6, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"Test"}', NULL, NULL, 'accepted', '2017-07-11 18:16:25', '2017-07-11 16:15:42', '2017-07-11 16:16:25'),
(7, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"bla"}', NULL, NULL, 'rejected', '2017-07-11 18:16:24', '2017-07-11 16:15:59', '2017-07-11 16:16:24'),
(8, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"Test2"}', NULL, NULL, 'rejected', '2017-09-11 17:34:30', '2017-09-11 13:20:39', '2017-09-11 15:34:30'),
(9, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"Test3"}', NULL, NULL, 'rejected', '2017-09-11 17:34:29', '2017-09-11 13:24:35', '2017-09-11 15:34:29'),
(10, 1335, 'Person', 1335, 'Person', 'update', '{"nickname":"Test3"}', NULL, NULL, 'rejected', '2017-09-11 17:34:28', '2017-09-11 15:34:02', '2017-09-11 15:34:28'),
(11, 1335, 'Person', 1079, 'PersonAddress', 'update', '{"country":"oesbekistan"}', NULL, NULL, 'rejected', '2017-09-11 17:42:33', '2017-09-11 15:42:20', '2017-09-11 15:42:33');

-- --------------------------------------------------------

--
-- Table structure for table `persons`
--

CREATE TABLE `persons` (
  `id` int(11) NOT NULL,
  `student_number` int(7) UNSIGNED DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `nickname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `initials` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `prefix` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sex` enum('m','f','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `date_of_death` date DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `mobile_phone` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `iban` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `building_access` enum('normal','weekend','always') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `debtor_code` int(11) DEFAULT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `draft` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `persons`
--

INSERT INTO `persons` (`id`, `student_number`, `first_name`, `nickname`, `initials`, `prefix`, `last_name`, `sex`, `date_of_birth`, `date_of_death`, `email`, `mobile_phone`, `iban`, `building_access`, `debtor_code`, `comments`, `draft`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1335, 4018575, 'Joseph', 'Test', 'J.P.', '', 'Verburg', 'other', '1991-01-16', NULL, 'josephverburg@gmail.com', '06-11847074', '', 'normal', 1163, '', NULL, NULL, '2016-11-28 16:21:13', '2017-07-11 16:16:25'),
(2061, 4318927, 'Erné', '', 'E.E.', '', 'Bronkhorst', 'm', '1993-05-18', NULL, 'ernebronkhorst@gmail.com', '06-81478802', '', 'normal', 1258, '', NULL, NULL, '2016-11-28 16:21:13', '2016-12-07 08:07:53'),
(2138, 4358163, 'Philip', '', 'P.C.', 'van den', 'Heuvel', 'm', '1996-07-19', NULL, 'philip6991@hotmail.com', '06-11833313', '', 'always', 1309, '', NULL, NULL, '2016-11-28 16:21:13', '2016-12-19 11:46:59'),
(2149, 4362233, 'Francesc', 'Cesc', 'F.', '', 'Varkevisser', 'm', '1996-03-11', NULL, 'cesc_varkevisser@hotmail.com', '06-25435052', '', 'normal', 1321, '', NULL, NULL, '2016-11-28 16:21:13', '2017-01-25 16:59:54'),
(2162, 4367928, 'Beau', '', 'B.', '', 'Fiechter', 'm', '1996-01-10', NULL, 'befiechter@gmail.com', '06-37119018', '', 'normal', 1276, '', NULL, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2306, 4449479, 'Tijs', '', 'T.', '', 'Moree', 'm', '1997-07-12', NULL, 'tijsmoree@gmail.com', '0642581480', '', 'normal', 1320, '', NULL, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2420, 4492242, 'Thomas', '', 'T.H.M.', '', 'Roos', 'm', '1997-12-05', NULL, 'thomasroos@live.nl', '0681536815', '', 'normal', NULL, '', NULL, NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Stand-in structure for view `persons_advanced`
--
CREATE TABLE `persons_advanced` (
`id` int(11)
,`student_number` int(7) unsigned
,`full_name` varchar(302)
,`formal_name` text
,`is_alive` int(1)
,`is_normal_member` int(1)
,`is_alumnus` int(1)
,`is_associate_member` int(1)
,`is_or_was_board_member` int(1)
,`is_committee_member` int(1)
,`is_or_was_committee_member` int(1)
,`is_honorary_member` int(1)
,`gender` varchar(7)
,`form_of_address` text
,`salutation` varchar(15)
,`first_name` varchar(100)
,`nickname` varchar(100)
,`initials` varchar(100)
,`prefix` varchar(100)
,`last_name` varchar(100)
,`sex` enum('m','f','other')
,`date_of_birth` date
,`date_of_death` date
,`email` varchar(100)
,`mobile_phone` varchar(45)
,`iban` varchar(45)
,`building_access` enum('normal','weekend','always')
,`debtor_code` int(11)
,`comments` text
,`draft` datetime
,`created_at` datetime
,`updated_at` datetime
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `persons_search`
--
CREATE TABLE `persons_search` (
`id` int(11)
,`searchblob` text
,`searchblob_advanced` mediumtext
,`relevance` bigint(24)
);

-- --------------------------------------------------------

--
-- Table structure for table `person_addresses`
--

CREATE TABLE `person_addresses` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `type` enum('home','parents') COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `town` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `person_addresses`
--

INSERT INTO `person_addresses` (`id`, `person_id`, `type`, `address`, `postal_code`, `town`, `country`, `phone_number`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1079, 1335, 'home', 'Van Hasseltlaan 562', '2625 JJ', 'Delft', '', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1849, 2061, 'home', 'Röntgenweg 137', '2624 BD', 'Delft', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1944, 2138, 'home', 'Simonstraat 84', '2628 TJ', 'Delft', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1955, 2149, 'home', 'Buitenwatersloot 177', '2613TE', 'Delft', '', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(1971, 2162, 'home', 'Mahlerstraat 38', '2625 AS', 'Delft', '', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2161, 2306, 'home', 'Arthur van Schendelplein 52', '2624 CP', 'Delft', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2289, 2420, 'home', 'Zuster Claassenhof 1', '1391 BL', 'Abcoude', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4335, 1335, 'parents', 'Roodborstlaan 18', '2566 ET', 'Den Haag', 'Nederland', '070-3647017', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4523, 2061, 'parents', 'Lingsespad 4', '4207 AR', 'Gorinchem', '', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4541, 2138, 'parents', 'Kees van Hasseltstraat 3', '3056 PC', 'Rotterdam', '', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4545, 2149, 'parents', 'Bloemendaalstraat 37', '2201 SW', 'Noordwijk', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4548, 2162, 'parents', 'Rijnstraat 47', '6665 CK', 'Driel', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4573, 2306, 'parents', 'Ribeslaan 80', '3053 MS', 'Rotterdam', 'Nederland', '', NULL, '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `person_pictures`
--

CREATE TABLE `person_pictures` (
  `id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `main` tinyint(1) NOT NULL DEFAULT '0',
  `file_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `person_pictures`
--

INSERT INTO `person_pictures` (`id`, `person_id`, `main`, `file_name`, `created_at`, `updated_at`) VALUES
(483, 1335, 0, 'LedenFotos/VerburgJoseph2009.jpg', '2016-11-28 16:21:14', '2016-11-28 17:17:25'),
(980, 2061, 1, 'LedenFotos/BronkhorstErne2013.jpg', '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1026, 2138, 1, 'LedenFotos/HeuvelPhilip2014.jpg', '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1035, 2149, 1, 'LedenFotos/VarkevisserFrancesc2014.jpg', '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1118, 2306, 1, 'LedenFotos/MoreeTijs2015.jpg', '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(1190, 2420, 1, 'LedenFotos/RoosThomas2015.jpg', '2016-11-28 16:21:14', '2016-11-28 16:21:14'),
(2091, 1335, 0, 'profile.jpg', '2017-09-11 12:58:54', '2017-09-11 13:05:12'),
(2092, 1335, 1, 'profile.jpg', '2017-09-11 13:05:12', '2017-09-11 13:05:12');

-- --------------------------------------------------------

--
-- Table structure for table `queries`
--

CREATE TABLE `queries` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queries`
--

INSERT INTO `queries` (`id`, `name`, `group`, `query`, `created_at`, `updated_at`) VALUES
(1, 'Adressen verenigingen extern', 'Maxwell', 'SELECT \n	salutation AS regel1, \n  associations.name AS regel2, \n  mail_address AS regel3, \n  CONCAT_WS('' '',mail_postal_code," ",mail_town) AS regel4, \n  IF(mail_country!=''Nederland'',mail_country,'''') AS regel5\nFROM associations \nINNER JOIN option_association_links l ON l.association_id = associations.id\nINNER JOIN options o ON o.id = l.option_id \nWHERE mail_internal = 0 AND o.name = ''Maxwell''', '2016-11-28 16:53:26', '2016-11-28 16:53:26'),
(2, 'Gewone leden', 'Maxwell', 'SELECT \n	salutation AS regel1, \n	formal_name AS regel2,\n	IF(a_home.id IS NULL, a_parents.address, a_home.address) AS regel3,\n  IF(a_home.id IS NULL, CONCAT_WS('' '', a_parents.postal_code, a_parents.town), CONCAT_WS('' '', a_home.postal_code, a_home.town)) AS regel4,\n  IF(a_home.id IS NULL, IF(a_parents.country != ''Nederland'', a_parents.country, ''''), IF(a_home.country != ''Nederland'', a_home.country, '''')) AS regel5\nFROM persons_advanced p\nLEFT JOIN person_addresses a_home ON a_home.person_id = p.id AND a_home.type = ''home'' AND a_home.deleted_at IS NULL\nLEFT JOIN person_addresses a_parents ON a_parents.person_id = p.id AND a_parents.type = ''parents'' AND a_parents.deleted_at IS NULL\nINNER JOIN normal_members m ON m.person_id = p.id AND deregistration IS NULL \nINNER JOIN option_person_links l ON l.person_id = p.id\nINNER JOIN options o ON o.id = l.option_id \nWHERE o.name = ''Maxwell'' AND is_alive = 1 AND (a_home.id IS NOT NULL OR a_parents.id IS NOT NULL)\nORDER BY formal_name\n', '2016-11-28 17:05:31', '2016-11-30 15:04:28'),
(3, 'Langstzittende commissieleden', 'Leden', 'SELECT p.full_name, c.short_name AS committee, cm.installation, cm.function_name\nFROM committee_members cm \nLEFT JOIN persons_advanced p ON p.id = cm.person_id \nLEFT JOIN committees c ON c.id = cm.committee_id \nWHERE discharge IS NULL AND type != ''fake''\nORDER BY installation ASC \nLIMIT 20', '2016-11-28 17:24:19', '2016-11-30 14:49:59'),
(5, 'Toegang', 'Leden', 'SELECT p.id AS person_id, full_name, building_access, GROUP_CONCAT(r.code SEPARATOR '', '') AS room_access FROM persons_advanced p\nLEFT JOIN room_access a ON p.id = a.person_id\nLEFT JOIN rooms r ON r.id = a.room_id\nWHERE p.building_access != ''normal''\nGROUP BY p.id\nORDER BY full_name', '2016-11-28 17:42:13', '2016-11-30 15:14:22'),
(7, 'Onder 18', 'Leden', 'SELECT p.id AS person_id, p.student_number, p.full_name, p.gender, p.date_of_birth, p.email, p.mobile_phone\nFROM persons_advanced p\nINNER JOIN normal_members n ON n.person_id = p.id AND deregistration IS NULL\nWHERE `date_of_birth` > ( curdate() - INTERVAL 18 YEAR )\nOR (`date_of_birth` = ''0000-00-00'' AND YEAR(registration) > 2015)', '2016-11-30 14:47:48', '2016-11-30 14:47:57'),
(8, 'EvV + EvB', 'Ereleden', 'SELECT  salutation, concat_ws(\n	'' '',\n	nullif(\n		CONCAT(\n			UCASE(\n				LEFT(prefix,1)\n			), \n			MID(prefix,2)\n		),\n		''''\n	),\n	last_name\n) AS name, \nform_of_address, formal_name, h.type, h.installation, address, CONCAT_WS('' '', postal_code, town) AS ''postcode en plaats'', country, mobile_phone, phone_number, email\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN honorary_members h ON h.person_id = p.id\nWHERE is_alive = 1 AND h.discharge IS NULL AND last_name != "Arnbak"\nORDER BY (h.type = ''erevoorzitter'') DESC, (h.type = ''evv'') DESC, h.installation', '2016-11-30 14:58:24', '2017-01-31 16:18:29'),
(9, 'Alleen EvB', 'Ereleden', 'SELECT p.id AS person_id, salutation, form_of_address, formal_name, IF(h.installation=''0000-00-00'',''Onbekend'',h.installation) AS installation, is_normal_member AS nog_lid, address, CONCAT_WS('' '', postal_code, town) AS ''postcode en plaats'', country, mobile_phone, phone_number, email\nFROM persons_advanced p\nLEFT JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN honorary_members h ON h.person_id = p.id AND h.type = ''evB''\nWHERE is_alive = 1 AND h.discharge IS NULL\nORDER BY h.installation DESC', '2016-11-30 15:07:57', '2017-01-31 16:19:45'),
(10, 'Reünisten', 'Leden', 'SELECT p.id AS person_id, salutation, form_of_address, formal_name, is_honorary_member, address, CONCAT_WS('' '', postal_code, town) AS ''postcode en plaats'', country, mobile_phone, phone_number, email\nFROM persons_advanced p\nLEFT JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nWHERE is_alive = 1 AND is_alumnus = 1\nORDER BY last_name', '2016-11-30 15:11:22', '2016-11-30 15:13:27'),
(11, 'Business-mailing', 'Mailing', 'SELECT full_name, first_name, email\nFROM persons_advanced p\nINNER JOIN option_person_links l ON l.person_id = p.id\nINNER JOIN options o ON o.id = l.option_id AND o.name = ''Bedrijvenmail''\nWHERE is_normal_member = 1 AND is_alive = 1 AND email != ''''\nORDER BY last_name', '2016-11-30 15:18:32', '2016-11-30 15:18:37'),
(12, 'Verenigingen', 'Kaartje', 'SELECT salutation AS regel1, a.name AS regel2, mail_address AS regel3, CONCAT_WS('' '', mail_postal_code, mail_town) AS regel4, IF(mail_country!=''Nederland'',mail_country,'''') AS regel5, mail_internal, form_of_address \nFROM associations a\nINNER JOIN option_association_links l ON l.association_id = a.id\nINNER JOIN options o ON o.id = l.option_id AND o.name = ''Kaartje''\nORDER BY mail_internal', '2016-11-30 15:23:18', '2016-11-30 15:23:18'),
(13, 'Laatste 10 Besturen', 'Kaartje', 'SELECT DISTINCT form_of_address AS regel1, formal_name AS regel2, address AS regel3, CONCAT_WS('' '',postal_code, town) AS regel4, IF(country!=''Nederland'',country,'''') AS regel5\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN board_members m ON m.person_id = p.id\nINNER JOIN boards b ON b.id = m.board_id\nWHERE is_alive = 1 AND b.number >= 135', '2016-11-30 15:28:25', '2016-12-08 15:20:25'),
(14, 'EvV', 'Kaartje', 'SELECT salutation, concat_ws(\n	'' '',\n	nullif(\n		CONCAT(\n			UCASE(\n				LEFT(prefix,1)\n			), \n			MID(prefix,2)\n		),\n		''''\n	),\n	last_name\n) AS name, form_of_address AS regel1, formal_name AS regel2, address AS regel3, CONCAT_WS('' '',postal_code, town) AS regel4, IF(country!=''Nederland'',country,'''') AS regel5\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN honorary_members h ON h.person_id = p.id AND h.type != ''evb''\nWHERE is_alive = 1 AND last_name != ''Arnbak''\nORDER BY country, last_name', '2016-11-30 15:28:54', '2017-01-31 14:10:57'),
(15, 'Eerstejaars', 'Kaartje', 'SELECT DISTINCT\n	form_of_address, \n	formal_name,\n	IF(a_home.id IS NULL, a_parents.address, a_home.address) AS address,\n  IF(a_home.id IS NULL, CONCAT_WS('' '', a_parents.postal_code, a_parents.town), CONCAT_WS('' '', a_home.postal_code, a_home.town)) AS regel3,\n  IF(a_home.id IS NULL, IF(a_parents.country != ''Nederland'', a_parents.country, ''''), IF(a_home.country != ''Nederland'', a_home.country, '''')) AS regel4\nFROM persons_advanced p\nLEFT JOIN person_addresses a_home ON a_home.person_id = p.id AND a_home.type = ''home'' AND a_home.deleted_at IS NULL\nLEFT JOIN person_addresses a_parents ON a_parents.person_id = p.id AND a_parents.type = ''parents'' AND a_parents.deleted_at IS NULL\nINNER JOIN normal_members m ON m.person_id = p.id AND deregistration IS NULL AND YEAR(registration) = 2016\nINNER JOIN normal_member_types t ON t.id = m.type_id AND t.type = ''bsc''\nWHERE is_alive = 1 AND (a_home.id IS NOT NULL OR a_parents.id IS NOT NULL)\nORDER BY last_name\n', '2016-11-30 15:35:00', '2016-12-08 16:13:22'),
(16, 'Commissie, geen sjaars of oud-bestuur', 'Kaartje', 'SELECT DISTINCT\n	form_of_address AS regel1, \n	formal_name AS regel2,\n	IF(a_home.id IS NULL, a_parents.address, a_home.address) AS regel3,\n  IF(a_home.id IS NULL, CONCAT_WS('' '', a_parents.postal_code, a_parents.town), CONCAT_WS('' '', a_home.postal_code, a_home.town)) AS regel4,\n  IF(a_home.id IS NULL, IF(a_parents.country != ''Nederland'', a_parents.country, ''''), IF(a_home.country != ''Nederland'', a_home.country, '''')) AS regel5\nFROM persons_advanced p\nLEFT JOIN person_addresses a_home ON a_home.person_id = p.id AND a_home.type = ''home'' AND a_home.deleted_at IS NULL\nLEFT JOIN person_addresses a_parents ON a_parents.person_id = p.id AND a_parents.type = ''parents'' AND a_parents.deleted_at IS NULL\nLEFT JOIN normal_members m ON m.person_id = p.id AND deregistration IS NULL AND YEAR(registration) = 2016\nLEFT JOIN normal_member_types t ON t.id = m.type_id AND t.type = ''bsc''\nWHERE is_alive = 1 AND is_committee_member = 1 AND is_or_was_board_member = 0 AND (a_home.id IS NOT NULL OR a_parents.id IS NOT NULL) AND t.id IS NULL\nORDER BY last_name', '2016-11-30 15:42:30', '2016-12-08 14:27:23'),
(17, 'Adressen verenigingen intern', 'Maxwell', 'SELECT \n	salutation AS regel1, \n  associations.name AS regel2, \n  mail_address AS regel3, \n  CONCAT_WS('' '',mail_postal_code," ",mail_town) AS regel4, \n  IF(mail_country!=''Nederland'',mail_country,'''') AS regel5\nFROM associations \nINNER JOIN option_association_links l ON l.association_id = associations.id\nINNER JOIN options o ON o.id = l.option_id \nWHERE mail_internal = 1 AND o.name = ''Maxwell''', '2016-11-30 15:47:33', '2016-11-30 15:47:33'),
(18, 'Reünisten Maxwell', 'Maxwell', 'SELECT form_of_address, formal_name, address, CONCAT_WS('' '', postal_code, town) AS ''postcode en plaats'', country\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN option_person_links l ON l.person_id = p.id\nINNER JOIN options o ON o.id = l.option_id AND o.name = ''Maxwell''\nWHERE is_alive = 1 AND is_alumnus = 1\nORDER BY last_name', '2016-11-30 15:55:50', '2016-11-30 15:56:05'),
(19, 'Mailinglist', 'Kobus', 'SELECT p.email, CONCAT(first_name," ",prefix," ",last_name) AS naam  \nFROM persons as p\nINNER JOIN committee_members as cm ON p.id = cm.person_id and cm.discharge is null\nINNER JOIN committees as c on cm.committee_id = c.id and c.type = ''normal'' group by p.id\n', '2016-12-20 08:52:28', '2016-12-20 08:58:52'),
(20, 'EESTEC', 'Mailing', 'SELECT  email\nFROM persons_advanced p\nINNER JOIN option_person_links l ON l.person_id = p.id\nINNER JOIN options o ON o.id = l.option_id AND o.name = ''EESTEC Mail''\nWHERE is_normal_member = 1 AND is_alive = 1 AND email != ''''\nORDER BY last_name', '2017-01-20 09:48:47', '2017-01-24 10:25:26'),
(21, 'Aanschrijven Verenigingen', 'Jaarboek', 'SELECT associations.name, salutation, type, email, mail_town\nFROM associations \nINNER JOIN option_association_links l ON l.association_id = associations.id\nINNER JOIN options o ON o.id = l.option_id \nWHERE o.name = ''Jaarboek''\nORDER BY name\n\n', '2017-01-20 14:01:29', '2017-01-20 14:03:00'),
(22, 'Ledenkatern', 'Jaarboek', 'SELECT \nIF(a_home.id IS NULL, a_parents.address, a_home.address) AS address,\nIF(a_home.id IS NULL, a_parents.postal_code, a_home.postal_code) AS postcode1,\nIF(a_home.id IS NULL, a_parents.town, a_home.town) AS plaats1,\nmobile_phone AS mobiel,\nlast_name AS naam, \nfirst_name AS roepnaam,\nEXTRACT(YEAR FROM registration) AS jaar_inschrijving,\nprefix AS voorvoegsels, initials AS voorletters, CONCAT(last_name, first_name, EXTRACT(YEAR FROM registration)) AS "@ellende"\nFROM persons_advanced p\nINNER JOIN normal_members m ON m.person_id = p.id AND deregistration IS NULL\nLEFT JOIN normal_member_types t ON t.id = m.type_id\nLEFT JOIN person_addresses a_home ON a_home.person_id = p.id AND a_home.type = ''home'' AND a_home.deleted_at IS NULL\nLEFT JOIN person_addresses a_parents ON a_parents.person_id = p.id AND a_parents.type = ''parents'' AND a_parents.deleted_at IS NULL\nWHERE is_alive = 1\nORDER BY last_name', '2017-01-25 16:55:38', '2017-01-25 16:55:38'),
(23, 'Ereleden', 'Maxwell', 'SELECT form_of_address AS regel1, formal_name AS regel2, address AS regel3, CONCAT_WS('' '',postal_code, town) AS regel4, IF(country!=''Nederland'',country,'''') AS regel5\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN honorary_members h ON h.person_id = p.id AND h.type != ''evb''\nWHERE is_alive = 1 AND last_name != ''Arnbak''\nORDER BY country, last_name', '2017-01-30 14:56:57', '2017-01-30 14:57:45'),
(24, 'Ouderdag', 'Leden', 'SELECT DISTINCT\n	CONCAT(''Aan de ouders/voogd van '') as regel1,\n  formal_name as regel2,\n	IF(a_home.id IS NULL, a_parents.address, a_home.address) AS regel3,\n  IF(a_home.id IS NULL, CONCAT_WS('' '', a_parents.postal_code, a_parents.town), CONCAT_WS('' '', a_home.postal_code, a_home.town)) AS regel4,\n  IF(a_home.id IS NULL, IF(a_parents.country != ''Nederland'', a_parents.country, ''''), IF(a_home.country != ''Nederland'', a_home.country, '''')) AS regel5, CONCAT(''Geachte ouders/voogd van '', full_name) AS aanspreek\nFROM persons_advanced p\nLEFT JOIN person_addresses a_home ON a_home.person_id = p.id AND a_home.type = ''home'' AND a_home.deleted_at IS NULL\nLEFT JOIN person_addresses a_parents ON a_parents.person_id = p.id AND a_parents.type = ''parents'' AND a_parents.deleted_at IS NULL\nINNER JOIN normal_members m ON m.person_id = p.id AND deregistration IS NULL AND YEAR(registration) = 2016\nINNER JOIN normal_member_types t ON t.id = m.type_id AND t.type = ''bsc''\nWHERE is_alive = 1 AND (a_home.id IS NOT NULL OR a_parents.id IS NOT NULL)\nORDER BY last_name\n', '2017-01-31 16:16:08', '2017-01-31 16:16:08'),
(25, 'Alleen EvV', 'Ereleden', 'SELECT salutation, concat_ws(\n	'' '',\n	nullif(\n		CONCAT(\n			UCASE(\n				LEFT(prefix,1)\n			), \n			MID(prefix,2)\n		),\n		''''\n	),\n	last_name\n) AS name, form_of_address AS regel1, formal_name AS regel2, address AS regel3, CONCAT_WS('' '',postal_code, town) AS regel4, IF(country!=''Nederland'',country,'''') AS regel5\nFROM persons_advanced p\nINNER JOIN person_addresses a ON a.person_id = p.id AND a.type = ''home'' AND a.deleted_at IS NULL\nINNER JOIN honorary_members h ON h.person_id = p.id AND h.type != ''evb''\nWHERE is_alive = 1 AND last_name != ''Arnbak''\nORDER BY country, last_name', '2017-01-31 16:19:37', '2017-01-31 16:19:37');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `code`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Bestuurskamer', 'HB00.522', NULL, '2016-11-28 17:22:55', '2016-11-28 17:22:55'),
(2, 'Vergaderhok', 'HB00.523', NULL, '2016-11-28 17:23:38', '2016-11-28 17:23:38'),
(3, 'Klushok', 'HB00.526', NULL, '2016-11-28 17:23:38', '2016-11-28 17:23:38'),
(4, 'Commissiehok', 'HB00.525', NULL, '2016-11-28 17:23:38', '2016-11-28 17:23:38'),
(5, 'Tweede Commissiehok', 'LH01.???', NULL, '2016-11-28 17:23:38', '2016-11-28 17:23:38'),
(6, 'Archief', 'LH00.', NULL, '2016-11-29 10:13:57', '2016-11-29 10:13:57'),
(9, 'Stunt opslaghok', 'LH00.?', NULL, '2016-11-29 10:14:30', '2016-11-30 10:56:13');

-- --------------------------------------------------------

--
-- Table structure for table `room_access`
--

CREATE TABLE `room_access` (
  `person_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `room_access`
--

INSERT INTO `room_access` (`person_id`, `room_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1335, 2, NULL, '2016-11-29 10:15:29', '2016-11-29 10:15:29'),
(1335, 4, NULL, '2016-11-29 10:15:29', '2016-11-29 10:15:29'),
(1335, 5, NULL, '2016-11-29 10:15:29', '2016-11-29 10:15:29'),
(2138, 1, NULL, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 2, NULL, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 3, NULL, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 4, NULL, '2016-11-29 08:03:54', '2016-11-29 08:03:54'),
(2138, 5, NULL, '2016-11-29 08:03:54', '2016-11-29 08:03:54');

-- --------------------------------------------------------

--
-- Table structure for table `titles`
--

CREATE TABLE `titles` (
  `id` int(11) NOT NULL,
  `title` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_of_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rank` int(11) NOT NULL,
  `front` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `titles`
--

INSERT INTO `titles` (`id`, `title`, `form_of_address`, `rank`, `front`, `created_at`, `updated_at`) VALUES
(1, 'jhr.', 'De hoogwelgeboren', 1, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(2, 'prof.', 'De hooggeleerde', 2, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(3, 'dr.h.c.', 'De weledelzeergeleerde', 3, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(4, 'dr.', 'De weledelzeergeleerde', 4, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(5, 'phd', 'De weledelzeergeleerde', 5, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(6, 'mr.', 'De weledelgestrenge', 6, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(7, 'ir.', 'De weledelgestrenge', 7, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(8, 'm.sc.', 'De weledelgestrenge', 8, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(9, 'drs.', 'De weledelgeleerde', 10, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(16, 'b.sc.', 'De weledelgeboren', 11, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(17, 'em.', 'De hooggeleerde', 2, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(18, 'b.eng.', 'De weledelgeboren', 11, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(19, 'eng.', 'De weledelgeboren', 11, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(20, 'b.ict.', 'De weledelgeboren', 11, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(21, 'b.ing.', 'De weledelgeboren', 11, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(22, 'm.ed.', 'De weledelgestrenge', 8, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(23, 'm.eng.', 'De weledelgestrenge', 8, 0, '2016-11-28 16:21:13', '2016-11-28 16:21:13'),
(24, 'ing.', 'De weledelgeboren', 11, 1, '2016-11-28 16:21:13', '2016-11-28 16:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `title_person_links`
--

CREATE TABLE `title_person_links` (
  `person_id` int(11) NOT NULL,
  `title_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure for view `persons_advanced`
--
DROP TABLE IF EXISTS `persons_advanced`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY INVOKER VIEW `persons_advanced`  AS  select `p`.`id` AS `id`,`p`.`student_number` AS `student_number`,concat(if((`p`.`first_name` <> ''),`p`.`first_name`,`p`.`initials`),if((`p`.`prefix` <> ''),' ',''),`p`.`prefix`,' ',`p`.`last_name`) AS `full_name`,concat(ifnull(concat(group_concat(distinct concat(ucase(left(`t_front`.`title`,1)),substr(`t_front`.`title`,2)) order by `t_front`.`rank` ASC separator ' '),' '),''),`p`.`initials`,if((`p`.`prefix` <> ''),' ',''),`p`.`prefix`,' ',`p`.`last_name`,ifnull(concat(' ',group_concat(distinct concat(ucase(left(`t_back`.`title`,1)),substr(`t_back`.`title`,2)) order by `t_back`.`rank` ASC separator ' ')),'')) AS `formal_name`,if(isnull(`p`.`date_of_death`),1,0) AS `is_alive`,if(isnull(`n`.`id`),0,1) AS `is_normal_member`,if(isnull(`a`.`id`),0,1) AS `is_alumnus`,if(isnull(`a_m`.`id`),0,1) AS `is_associate_member`,if(isnull(`b_m`.`person_id`),0,1) AS `is_or_was_board_member`,if(isnull(`c_m`.`person_id`),0,1) AS `is_committee_member`,if(isnull(`c_m2`.`person_id`),0,1) AS `is_or_was_committee_member`,if(isnull(`h`.`person_id`),0,1) AS `is_honorary_member`,if((`p`.`sex` = 'm'),'heer',if((`p`.`sex` = 'f'),'mevrouw','')) AS `gender`,concat(ifnull(substring_index(group_concat(`t`.`form_of_address` order by `t`.`rank` ASC separator ','),',',1),'De weledelgeboren'),ifnull(concat(' ',if((`p`.`sex` = 'm'),'heer',if((`p`.`sex` = 'f'),'mevrouw',''))),'')) AS `form_of_address`,concat('Geachte',ifnull(concat(' ',if((`p`.`sex` = 'm'),'heer',if((`p`.`sex` = 'f'),'mevrouw',''))),'')) AS `salutation`,`p`.`first_name` AS `first_name`,`p`.`nickname` AS `nickname`,`p`.`initials` AS `initials`,`p`.`prefix` AS `prefix`,`p`.`last_name` AS `last_name`,`p`.`sex` AS `sex`,`p`.`date_of_birth` AS `date_of_birth`,`p`.`date_of_death` AS `date_of_death`,`p`.`email` AS `email`,`p`.`mobile_phone` AS `mobile_phone`,`p`.`iban` AS `iban`,`p`.`building_access` AS `building_access`,`p`.`debtor_code` AS `debtor_code`,`p`.`comments` AS `comments`,`p`.`draft` AS `draft`,`p`.`created_at` AS `created_at`,`p`.`updated_at` AS `updated_at` from (((((((((((`persons` `p` left join `title_person_links` `tpl` on((`tpl`.`person_id` = `p`.`id`))) left join `titles` `t` on((`t`.`id` = `tpl`.`title_id`))) left join `titles` `t_front` on(((`t_front`.`id` = `tpl`.`title_id`) and (`t_front`.`front` = 1)))) left join `titles` `t_back` on(((`t_back`.`id` = `tpl`.`title_id`) and (`t_back`.`front` = 0)))) left join `normal_members` `n` on(((`n`.`person_id` = `p`.`id`) and isnull(`n`.`deregistration`)))) left join `alumni` `a` on(((`a`.`person_id` = `p`.`id`) and isnull(`a`.`deregistration`)))) left join `associate_members` `a_m` on(((`a_m`.`person_id` = `p`.`id`) and isnull(`a_m`.`deregistration`)))) left join `board_members` `b_m` on((`b_m`.`person_id` = `p`.`id`))) left join `committee_members` `c_m` on(((`c_m`.`person_id` = `p`.`id`) and isnull(`c_m`.`discharge`)))) left join `committee_members` `c_m2` on((`c_m2`.`person_id` = `p`.`id`))) left join `honorary_members` `h` on(((`h`.`person_id` = `p`.`id`) and isnull(`h`.`discharge`)))) where isnull(`p`.`deleted_at`) group by `p`.`id` ;

-- --------------------------------------------------------

--
-- Structure for view `persons_search`
--
DROP TABLE IF EXISTS `persons_search`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY INVOKER VIEW `persons_search`  AS  select `persons`.`id` AS `id`,concat_ws(' ',`persons`.`first_name`,`persons`.`nickname`,`persons`.`initials`,`persons`.`prefix`,`persons`.`last_name`,`persons`.`email`,`persons`.`mobile_phone`,`person_addresses`.`address`,`person_addresses`.`postal_code`,`person_addresses`.`town`,`person_addresses`.`country`,`person_addresses`.`phone_number`) AS `searchblob`,concat_ws(' ',`persons`.`first_name`,`persons`.`nickname`,`persons`.`initials`,`persons`.`prefix`,`persons`.`last_name`,`persons`.`email`,`persons`.`mobile_phone`,`person_addresses`.`address`,`person_addresses`.`postal_code`,`person_addresses`.`town`,`person_addresses`.`country`,`person_addresses`.`phone_number`,`persons`.`student_number`,if((`persons`.`sex` = 'm'),'Man',if((`persons`.`sex` = 'f'),'Vrouw','Anders')),`persons`.`date_of_birth`,`persons`.`comments`,year(`normal_members`.`registration`)) AS `searchblob_advanced`,(((count(distinct `board_members`.`board_id`) * 8) + if((count(distinct `committee_members`.`id`) > 0),greatest((count(distinct `committee_members`.`id`) * 2),5),0)) + ifnull(ifnull(year(`normal_members`.`registration`),year(`honorary_members`.`installation`)),(year(`persons`.`date_of_birth`) + 16))) AS `relevance` from (((((`persons` left join `board_members` on((`board_members`.`person_id` = `persons`.`id`))) left join `committee_members` on(((`committee_members`.`person_id` = `persons`.`id`) and isnull(`committee_members`.`discharge`)))) left join `honorary_members` on((`honorary_members`.`person_id` = `persons`.`id`))) left join `normal_members` on((`normal_members`.`person_id` = `persons`.`id`))) left join `person_addresses` on(((`persons`.`id` = `person_addresses`.`person_id`) and isnull(`person_addresses`.`deleted_at`)))) where isnull(`persons`.`deleted_at`) group by `persons`.`id`,`person_addresses`.`id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_alumni_persons1_idx` (`person_id`);

--
-- Indexes for table `associate_members`
--
ALTER TABLE `associate_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_group_buitengewoon_lid_persons1_idx` (`person_id`);

--
-- Indexes for table `associations`
--
ALTER TABLE `associations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `boards`
--
ALTER TABLE `boards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nr` (`number`);

--
-- Indexes for table `board_members`
--
ALTER TABLE `board_members`
  ADD PRIMARY KEY (`person_id`,`board_id`),
  ADD KEY `fk_persons_has_boards_boards1_idx` (`board_id`),
  ADD KEY `fk_persons_has_boards_persons1_idx` (`person_id`);

--
-- Indexes for table `board_pictures`
--
ALTER TABLE `board_pictures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fp_board_pictures_board_id` (`board_id`);

--
-- Indexes for table `committees`
--
ALTER TABLE `committees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `committee_members`
--
ALTER TABLE `committee_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_persons_has_committees_committees1_idx` (`committee_id`),
  ADD KEY `fk_persons_has_committees_persons1_idx` (`person_id`);

--
-- Indexes for table `faculty_departments`
--
ALTER TABLE `faculty_departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_employees`
--
ALTER TABLE `faculty_employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `person_id_UNIQUE` (`person_id`),
  ADD KEY `fk_persons_has_faculty_departments_persons1_idx` (`person_id`);

--
-- Indexes for table `faculty_employee_departments`
--
ALTER TABLE `faculty_employee_departments`
  ADD PRIMARY KEY (`faculty_employees_id`,`faculty_departments_id`),
  ADD KEY `fk_faculty_employees_has_faculty_departments_faculty_depart_idx` (`faculty_departments_id`),
  ADD KEY `fk_faculty_employees_has_faculty_departments_faculty_employ_idx` (`faculty_employees_id`);

--
-- Indexes for table `honorary_members`
--
ALTER TABLE `honorary_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_honorary_members_persons1_idx` (`person_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `normal_members`
--
ALTER TABLE `normal_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_normal_member_persons1_idx` (`person_id`),
  ADD KEY `fk_normal_members_educations1_idx` (`type_id`);

--
-- Indexes for table `normal_member_types`
--
ALTER TABLE `normal_member_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`);

--
-- Indexes for table `option_association_links`
--
ALTER TABLE `option_association_links`
  ADD PRIMARY KEY (`association_id`,`option_id`),
  ADD KEY `fk_options_has_associations_options1_idx` (`option_id`);

--
-- Indexes for table `option_person_links`
--
ALTER TABLE `option_person_links`
  ADD PRIMARY KEY (`person_id`,`option_id`),
  ADD KEY `fk_persons_has_ticks_ticks1_idx` (`option_id`),
  ADD KEY `fk_persons_has_ticks_persons1_idx` (`person_id`);

--
-- Indexes for table `pending_changes`
--
ALTER TABLE `pending_changes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `persons`
--
ALTER TABLE `persons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `student_number_UNIQUE` (`student_number`);

--
-- Indexes for table `person_addresses`
--
ALTER TABLE `person_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_adresses_persons1` (`person_id`);

--
-- Indexes for table `person_pictures`
--
ALTER TABLE `person_pictures`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_person_pictures_persons1_idx` (`person_id`);

--
-- Indexes for table `queries`
--
ALTER TABLE `queries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `room_code_UNIQUE` (`code`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`);

--
-- Indexes for table `room_access`
--
ALTER TABLE `room_access`
  ADD PRIMARY KEY (`person_id`,`room_id`),
  ADD KEY `fk_persons_has_rooms_rooms1_idx` (`room_id`),
  ADD KEY `fk_persons_has_rooms_persons1_idx` (`person_id`);

--
-- Indexes for table `titles`
--
ALTER TABLE `titles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title_UNIQUE` (`title`),
  ADD KEY `priority` (`front`);

--
-- Indexes for table `title_person_links`
--
ALTER TABLE `title_person_links`
  ADD PRIMARY KEY (`person_id`,`title_id`),
  ADD KEY `fk_titles_has_titles` (`title_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=513;
--
-- AUTO_INCREMENT for table `associate_members`
--
ALTER TABLE `associate_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `associations`
--
ALTER TABLE `associations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `boards`
--
ALTER TABLE `boards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT for table `board_pictures`
--
ALTER TABLE `board_pictures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=271;
--
-- AUTO_INCREMENT for table `committees`
--
ALTER TABLE `committees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
--
-- AUTO_INCREMENT for table `committee_members`
--
ALTER TABLE `committee_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2055;
--
-- AUTO_INCREMENT for table `faculty_departments`
--
ALTER TABLE `faculty_departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty_employees`
--
ALTER TABLE `faculty_employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `honorary_members`
--
ALTER TABLE `honorary_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=364;
--
-- AUTO_INCREMENT for table `normal_members`
--
ALTER TABLE `normal_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3188;
--
-- AUTO_INCREMENT for table `normal_member_types`
--
ALTER TABLE `normal_member_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `pending_changes`
--
ALTER TABLE `pending_changes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `persons`
--
ALTER TABLE `persons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6663;
--
-- AUTO_INCREMENT for table `person_addresses`
--
ALTER TABLE `person_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5129;
--
-- AUTO_INCREMENT for table `person_pictures`
--
ALTER TABLE `person_pictures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2093;
--
-- AUTO_INCREMENT for table `queries`
--
ALTER TABLE `queries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `titles`
--
ALTER TABLE `titles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `alumni`
--
ALTER TABLE `alumni`
  ADD CONSTRAINT `fk_alumni_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `associate_members`
--
ALTER TABLE `associate_members`
  ADD CONSTRAINT `fk_group_buitengewoon_lid_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `board_members`
--
ALTER TABLE `board_members`
  ADD CONSTRAINT `fk_persons_has_boards_boards1` FOREIGN KEY (`board_id`) REFERENCES `boards` (`id`),
  ADD CONSTRAINT `fk_persons_has_boards_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `board_pictures`
--
ALTER TABLE `board_pictures`
  ADD CONSTRAINT `fp_board_pictures_board_id` FOREIGN KEY (`board_id`) REFERENCES `boards` (`id`);

--
-- Constraints for table `committee_members`
--
ALTER TABLE `committee_members`
  ADD CONSTRAINT `fk_persons_has_committees_committees1` FOREIGN KEY (`committee_id`) REFERENCES `committees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_persons_has_committees_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `faculty_employees`
--
ALTER TABLE `faculty_employees`
  ADD CONSTRAINT `fk_persons_has_faculty_departments_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`);

--
-- Constraints for table `faculty_employee_departments`
--
ALTER TABLE `faculty_employee_departments`
  ADD CONSTRAINT `fk_faculty_employees_has_faculty_departments_faculty_departme1` FOREIGN KEY (`faculty_departments_id`) REFERENCES `faculty_departments` (`id`),
  ADD CONSTRAINT `fk_faculty_employees_has_faculty_departments_faculty_employees1` FOREIGN KEY (`faculty_employees_id`) REFERENCES `faculty_employees` (`id`);

--
-- Constraints for table `honorary_members`
--
ALTER TABLE `honorary_members`
  ADD CONSTRAINT `fk_honorary_members_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `normal_members`
--
ALTER TABLE `normal_members`
  ADD CONSTRAINT `fk_normal_member_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_normal_members_educations1` FOREIGN KEY (`type_id`) REFERENCES `normal_member_types` (`id`);

--
-- Constraints for table `option_association_links`
--
ALTER TABLE `option_association_links`
  ADD CONSTRAINT `fk_option_association_links_associations1` FOREIGN KEY (`association_id`) REFERENCES `associations` (`id`),
  ADD CONSTRAINT `fk_options_has_associations_options1` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`);

--
-- Constraints for table `option_person_links`
--
ALTER TABLE `option_person_links`
  ADD CONSTRAINT `fk_persons_has_ticks_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_persons_has_ticks_ticks1` FOREIGN KEY (`option_id`) REFERENCES `options` (`id`);

--
-- Constraints for table `person_addresses`
--
ALTER TABLE `person_addresses`
  ADD CONSTRAINT `fk_adresses_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `person_pictures`
--
ALTER TABLE `person_pictures`
  ADD CONSTRAINT `fk_person_pictures_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room_access`
--
ALTER TABLE `room_access`
  ADD CONSTRAINT `fk_persons_has_rooms_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_persons_has_rooms_rooms1` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`);

--
-- Constraints for table `title_person_links`
--
ALTER TABLE `title_person_links`
  ADD CONSTRAINT `fk_titles_has_persons1` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_titles_has_titles` FOREIGN KEY (`title_id`) REFERENCES `titles` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
